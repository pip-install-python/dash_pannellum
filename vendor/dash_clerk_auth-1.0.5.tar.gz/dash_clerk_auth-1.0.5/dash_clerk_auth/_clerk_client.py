"""Async Clerk SDK wrapper + TTL caches.

The SDK ``clerk-backend-api>=5`` already manages a shared
``httpx.AsyncClient`` pool internally, so we just reuse a single
``Clerk`` instance via ``get_async_client()``.

Three caches keep the hot path off Clerk's network:

- A verified-positive cache keyed on JWT ``jti`` (5 min TTL by default)
  so the same session cookie doesn't roundtrip on every Dash POST.
- A user-by-id cache for ``aget_user_by_id`` (60 s default).
- A user-list cache for ``alist_users_cached`` so admin pages don't
  paginate Clerk on every render.

All caches honour ``force=True`` for explicit invalidation (refresh
buttons) and have an in-flight de-dup so 50 concurrent reads collapse
to a single Clerk call.
"""

from __future__ import annotations

import asyncio
import dataclasses
import logging
import os
import threading
import time
from functools import lru_cache
from typing import Any, Awaitable, Callable, Dict, List, Mapping, Optional, Tuple

import httpx

from ._user import ClerkUser

logger = logging.getLogger(__name__)


def _is_closed_loop_error(exc: BaseException) -> bool:
    """True for the ``RuntimeError: Event loop is closed`` family.

    Dash 4.2 runs each async WebSocket callback via ``asyncio.run()`` in a
    rotating thread-pool worker (``dash/backends/ws.py``), so a process-cached
    ``httpx.AsyncClient`` whose connection pool bound to an earlier (now
    closed) loop raises this on reuse from another worker. We detect it so the
    cached client can be rebuilt and the call retried once — see
    :func:`averify_request`. Application code should prefer the loop-free
    *sync* helpers (:func:`verify_user_sync` et al.) from inside callback
    bodies instead of relying on this safety net.
    """
    if isinstance(exc, RuntimeError):
        msg = str(exc).lower()
        return (
            "event loop is closed" in msg
            # Future created on loop A, awaited on loop B (asyncio.tasks):
            or "attached to a different loop" in msg
            # asyncio Lock/Event/Semaphore reused across loops, incl. the
            # anyio primitives httpcore wraps inside httpx's pool
            # (asyncio.mixins raises "<obj> is bound to a different event loop"):
            or ("bound to a different" in msg and "loop" in msg)
        )
    return False


# ---------------------------------------------------------------------------
# Singleton async Clerk client
# ---------------------------------------------------------------------------
@lru_cache(maxsize=1)
def get_async_client():
    """Return the process-wide :class:`clerk_backend_api.Clerk` instance.

    The SDK manages its own ``httpx.AsyncClient`` pool — reusing the
    same ``Clerk`` ensures every coroutine shares the same TCP/HTTP/2
    connections to the Clerk API.

    Reads ``CLERK_SECRET_KEY`` from the env on first call. Override by
    calling :func:`set_async_client` before any other helper.
    """
    from clerk_backend_api import Clerk

    secret = _override_secret or os.environ.get("CLERK_SECRET_KEY")
    if not secret:
        raise RuntimeError(
            "CLERK_SECRET_KEY is not set. Either pass clerk_secret_key= to "
            "register_clerk_auth() or export CLERK_SECRET_KEY in the env."
        )
    return Clerk(bearer_auth=secret)


@lru_cache(maxsize=1)
def get_sync_client():
    """Return the process-wide **synchronous** :class:`clerk_backend_api.Clerk`.

    This is the loop-free twin of :func:`get_async_client`. Its underlying
    ``httpx.Client`` is never bound to an asyncio event loop, so it is safe to
    call from **any** thread — including Dash 4.2's WebSocket callback worker
    threads and ``jobs.py`` daemon threads, where the async client's
    loop-bound pool would raise ``RuntimeError: Event loop is closed``.

    Use it via :func:`verify_user_sync`, :func:`get_user_by_id_sync` and
    :func:`list_users_sync` rather than directly.
    """
    from clerk_backend_api import Clerk

    secret = _override_secret or os.environ.get("CLERK_SECRET_KEY")
    if not secret:
        raise RuntimeError(
            "CLERK_SECRET_KEY is not set. Either pass clerk_secret_key= to "
            "register_clerk_auth() or export CLERK_SECRET_KEY in the env."
        )
    return Clerk(bearer_auth=secret)


_override_secret: Optional[str] = None


def set_async_client_secret(secret: str) -> None:
    """Set the Clerk secret used to construct the singleton clients.

    Called by ``register_clerk_auth()``. Resets BOTH cached singletons (async
    and sync) so the next ``get_async_client()`` / ``get_sync_client()`` picks
    up the new secret.
    """
    global _override_secret
    _override_secret = secret
    get_async_client.cache_clear()
    get_sync_client.cache_clear()


# ---------------------------------------------------------------------------
# Tiny TTL cache primitive — no external dep on cachetools.
# ---------------------------------------------------------------------------
class _TTLCache:
    """Async-safe TTL cache with single-flight semantics.

    ``await get(key, loader)`` returns the cached value if fresh, otherwise
    ``await``s ``loader()`` exactly once even under concurrent access.
    """

    def __init__(self, default_ttl: float = 60.0, maxsize: int = 1024):
        self._default_ttl = default_ttl
        self._maxsize = maxsize
        self._store: Dict[Any, Tuple[float, Any]] = {}
        self._inflight: Dict[Any, "asyncio.Future"] = {}
        self._lock = asyncio.Lock()

    def _evict_if_needed(self) -> None:
        if len(self._store) <= self._maxsize:
            return
        # Drop the 25% oldest entries by expiry time. Cheap, good enough.
        cutoff = sorted(self._store.items(), key=lambda kv: kv[1][0])
        for k, _ in cutoff[: max(1, self._maxsize // 4)]:
            self._store.pop(k, None)

    def get_sync(self, key: Any) -> Optional[Any]:
        entry = self._store.get(key)
        if entry is None:
            return None
        expires_at, value = entry
        if expires_at < time.monotonic():
            self._store.pop(key, None)
            return None
        return value

    def put(self, key: Any, value: Any, ttl: Optional[float] = None) -> None:
        ttl = ttl if ttl is not None else self._default_ttl
        self._store[key] = (time.monotonic() + ttl, value)
        self._evict_if_needed()

    def invalidate(self, key: Any) -> None:
        self._store.pop(key, None)

    def clear(self) -> None:
        self._store.clear()

    async def get_or_load(
        self,
        key: Any,
        loader: Callable[[], Awaitable[Any]],
        *,
        ttl: Optional[float] = None,
        force: bool = False,
    ) -> Any:
        if not force:
            cached = self.get_sync(key)
            if cached is not None:
                return cached

        try:
            return await self._coordinated_load(key, loader, ttl=ttl, force=force)
        except RuntimeError as exc:
            # Cross-loop reuse. This cache's ``asyncio.Lock`` and single-flight
            # ``Future`` bind to the FIRST event loop that touches them; Dash
            # 4.2 runs each WS callback via ``asyncio.run()`` in a worker with
            # its OWN loop, so a second loop awaiting them raises
            # "event loop is closed" / "attached to" / "bound to a different
            # ... loop". The lock is the first tripwire, before we could even
            # inspect the future's loop — so the only complete fix is to
            # degrade gracefully: drop the shared single-flight and run the
            # loader directly on THIS loop (a rare duplicate Clerk call is
            # fine). The *supported* path for worker threads is the sync
            # helpers (get_user_by_id_sync / list_users_sync); this is a net.
            if not _is_closed_loop_error(exc):
                raise
            logger.info(
                "TTL cache single-flight hit a cross-loop reuse; running the "
                "loader directly on the current loop. Prefer the *_sync helpers "
                "from WS callback bodies / worker threads."
            )
            return await loader()

    async def _coordinated_load(
        self,
        key: Any,
        loader: Callable[[], Awaitable[Any]],
        *,
        ttl: Optional[float] = None,
        force: bool = False,
    ) -> Any:
        # Single-flight: if another coroutine is already loading this key,
        # await its future instead of issuing a duplicate request. The
        # ``asyncio.Lock`` gates entry, so every caller that reaches the
        # ``existing``/future handshake is on the lock's own loop — which is
        # why a cross-loop caller fails at ``async with self._lock`` above and
        # is handled by the degrade path in :meth:`get_or_load`.
        async with self._lock:
            if not force:
                cached = self.get_sync(key)
                if cached is not None:
                    return cached
            existing = self._inflight.get(key)
            if existing is not None:
                fut = existing
            else:
                # ``get_running_loop`` (not the deprecated ``get_event_loop``)
                # so the future is bound to the loop that created it.
                fut = asyncio.get_running_loop().create_future()
                self._inflight[key] = fut

        if existing is not None:
            return await fut

        try:
            value = await loader()
            self.put(key, value, ttl=ttl)
            fut.set_result(value)
            return value
        except BaseException as exc:
            fut.set_exception(exc)
            raise
        finally:
            async with self._lock:
                self._inflight.pop(key, None)


# Module-level caches. Re-instantiate via _reset_caches() in tests.
_jti_cache = _TTLCache(default_ttl=300.0, maxsize=4096)
_user_cache = _TTLCache(default_ttl=60.0, maxsize=2048)
_user_list_cache = _TTLCache(default_ttl=60.0, maxsize=64)


class _SyncTTLCache:
    """A plain, thread-safe TTL cache for the synchronous helpers.

    The async :class:`_TTLCache` guards its single-flight path with an
    ``asyncio.Lock`` (loop-bound), so it is the wrong tool for values produced
    on Dash's WS worker threads. This sibling uses a ``threading.Lock`` and is
    safe to read/write from any thread. No single-flight — the sync helpers are
    only called from worker threads where a rare duplicate Clerk call is
    cheaper than cross-thread coordination.
    """

    def __init__(self, default_ttl: float = 300.0, maxsize: int = 4096):
        self._default_ttl = default_ttl
        self._maxsize = maxsize
        self._store: Dict[Any, Tuple[float, Any]] = {}
        self._lock = threading.Lock()

    def get(self, key: Any) -> Optional[Any]:
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            expires_at, value = entry
            if expires_at < time.monotonic():
                self._store.pop(key, None)
                return None
            return value

    def put(self, key: Any, value: Any, ttl: Optional[float] = None) -> None:
        ttl = ttl if ttl is not None else self._default_ttl
        with self._lock:
            self._store[key] = (time.monotonic() + ttl, value)
            if len(self._store) > self._maxsize:
                # Drop the oldest 25% (iterate a snapshot under the lock).
                ordered = sorted(self._store.items(), key=lambda kv: kv[1][0])
                for k, _ in ordered[: max(1, self._maxsize // 4)]:
                    self._store.pop(k, None)

    def invalidate(self, key: Any) -> None:
        with self._lock:
            self._store.pop(key, None)

    def clear(self) -> None:
        with self._lock:
            self._store.clear()


_sync_jti_cache = _SyncTTLCache(default_ttl=300.0, maxsize=4096)
_sync_user_cache = _SyncTTLCache(default_ttl=60.0, maxsize=2048)
_sync_user_list_cache = _SyncTTLCache(default_ttl=60.0, maxsize=64)


def _reset_caches() -> None:
    """Clear every module cache. Test-only; not part of the public API."""
    _jti_cache.clear()
    _user_cache.clear()
    _user_list_cache.clear()
    _sync_jti_cache.clear()
    _sync_user_cache.clear()
    _sync_user_list_cache.clear()
    with _enrichment_lock:
        _enrichment_by_user_id.clear()


# ---------------------------------------------------------------------------
# Identity enrichment — Clerk session JWTs carry no email claim by default
# ---------------------------------------------------------------------------
# A stock Clerk session token is just {azp, exp, iat, iss, sid, sts, sub, v}:
# no email, no name. Without enrichment every verified user comes out
# email-less, gets jti-cached email-less, and is minted into __dca_identity
# email-less for the cookie's whole lifetime — so an email-keyed gate
# (user.email == OWNER_EMAIL) denies users Clerk verified successfully.
#
# After a positive verify whose payload lacks an email, the verify helpers
# fetch the user once via the users API and remember the identity fields per
# user_id for the process lifetime (a primary email changing mid-process is
# not worth re-fetching for). Enrichment runs BEFORE the verdict is jti-cached
# and before any __dca_identity mint, so it costs one backend-API call per
# user per process — not per request.

_ENRICH_FIELDS = ("email", "first_name", "last_name", "image_url")

# user_id -> {field: value} captured from a successful users.get. Sticky for
# the process lifetime; "fetched but Clerk has no email" is remembered too so
# phone-only users don't re-fetch on every verify. Transient fetch failures
# are NOT remembered — the next slow-path verify retries.
_enrichment_by_user_id: Dict[str, Dict[str, Any]] = {}
_enrichment_lock = threading.Lock()
_ENRICHMENT_MAXSIZE = 10_000


def _needs_enrichment(user: ClerkUser) -> bool:
    return user.email is None and bool(user.user_id)


def _remember_enrichment(user_id: str, data: Mapping[str, Any]) -> Dict[str, Any]:
    fields = {f: data.get(f) for f in _ENRICH_FIELDS}
    with _enrichment_lock:
        if len(_enrichment_by_user_id) >= _ENRICHMENT_MAXSIZE:
            _enrichment_by_user_id.clear()
        _enrichment_by_user_id[user_id] = fields
    return fields


def _apply_enrichment(user: ClerkUser, fields: Mapping[str, Any]) -> ClerkUser:
    updates = {
        f: fields[f]
        for f in _ENRICH_FIELDS
        if getattr(user, f) is None and fields.get(f)
    }
    return dataclasses.replace(user, **updates) if updates else user


def enrich_user_sync(user: ClerkUser) -> ClerkUser:
    """Fill missing email/name/image on a verified user via the users API.

    No-op when the user already has an email (e.g. the Clerk instance
    customises its session token with ``{{user.primary_email_address}}``).
    Loop-free — safe from Flask request handlers, WS callback bodies and
    job threads. The underlying fetch is TTL-cached and the resolved
    fields are remembered per user_id for the process lifetime.
    """
    if not _needs_enrichment(user):
        return user
    with _enrichment_lock:
        fields = _enrichment_by_user_id.get(user.user_id)
    if fields is None:
        data = get_user_by_id_sync(user.user_id)
        if data is None:
            return user
        fields = _remember_enrichment(user.user_id, data)
    return _apply_enrichment(user, fields)


async def aenrich_user(user: ClerkUser) -> ClerkUser:
    """Async twin of :func:`enrich_user_sync` — main event loop only."""
    if not _needs_enrichment(user):
        return user
    with _enrichment_lock:
        fields = _enrichment_by_user_id.get(user.user_id)
    if fields is None:
        data = await aget_user_by_id(user.user_id)
        if data is None:
            return user
        fields = _remember_enrichment(user.user_id, data)
    return _apply_enrichment(user, fields)


# ---------------------------------------------------------------------------
# Public async helpers
# ---------------------------------------------------------------------------
def _build_httpx_request(
    method: str,
    url: str,
    headers: Mapping[str, str],
    cookies: Optional[Mapping[str, str]] = None,
    *,
    bearer_token: Optional[str] = None,
) -> httpx.Request:
    """Construct the httpx.Request fed to ``Clerk.authenticate_request``.

    IMPORTANT — two non-obvious bits of cookie hygiene live here, both
    learned the hard way from real-world failure modes.

    1. We do NOT pass ``cookies=`` to ``httpx.Request``. When httpx
       receives both an explicit ``cookies={...}`` dict AND a pre-existing
       ``Cookie:`` header in ``headers``, it OVERWRITES the header from
       the dict — which loses any cookies the dict didn't enumerate.

    2. We STRIP per-instance Clerk cookies (``__session_<suffix>``,
       ``__client_uat_<suffix>``, ``__refresh_<suffix>``) from the Cookie
       header before handing it to Clerk's SDK. Reason: when a developer
       has signed into multiple Clerk apps on the same hostname (very
       common on ``localhost`` / ``127.0.0.1`` during development), the
       browser carries every app's per-suffix cookies on every request.
       Clerk's backend SDK reads cookies in declaration order and picks
       the FIRST ``__session*`` it sees — which may be from a different
       Clerk app. The result is a ``JWK_KID_MISMATCH`` rejection on every
       request even though the canonical ``__session`` cookie is valid.
       Stripping the suffixed variants forces the SDK to use the canonical
       ``__session`` (which Clerk JS always sets for backwards compat),
       which is guaranteed to be the current app's session.
    """
    h = dict(headers)
    if bearer_token and "authorization" not in {k.lower() for k in h}:
        h["Authorization"] = f"Bearer {bearer_token}"

    # Filter the Cookie header (if present) to remove other-app variants.
    cookie_key = next((k for k in h if k.lower() == "cookie"), None)
    if cookie_key is not None:
        h[cookie_key] = _filter_other_app_clerk_cookies(h[cookie_key])

    if cookies and not any(k.lower() == "cookie" for k in h):
        # Caller supplied cookies but no Cookie header — synthesize one,
        # also filtered.
        raw = "; ".join(f"{k}={v}" for k, v in cookies.items())
        h["Cookie"] = _filter_other_app_clerk_cookies(raw)

    return httpx.Request(method=method, url=url, headers=h)


# Cookie names that Clerk's per-instance suffix scheme can produce. Anything
# matching ``<base>_<suffix>`` (where ``<suffix>`` is the publishable-key
# hash Clerk uses to multiplex apps on the same hostname) gets stripped so
# the SDK falls back to the canonical, no-suffix cookie which is always set
# for the active app.
_CLERK_SUFFIXED_COOKIE_BASES = ("__session", "__client_uat", "__refresh", "__clerk_db_jwt")


def _filter_other_app_clerk_cookies(cookie_header: str) -> str:
    """Drop ``<base>_<suffix>`` Clerk cookies from a raw Cookie header.

    Keeps the canonical no-suffix variants (``__session``, ``__client_uat``,
    etc.) so Clerk's SDK reads the right session even when the browser
    carries cookies from other Clerk apps for the same hostname. See the
    docstring on :func:`_build_httpx_request` for the full rationale.
    """
    if not cookie_header:
        return cookie_header
    kept: list[str] = []
    for raw in cookie_header.split(";"):
        item = raw.strip()
        if not item:
            continue
        name = item.split("=", 1)[0]
        # Drop suffixed variants only — leave the canonical names alone.
        if any(
            name.startswith(base + "_") and name != base
            for base in _CLERK_SUFFIXED_COOKIE_BASES
        ):
            continue
        kept.append(item)
    return "; ".join(kept)


# ---------------------------------------------------------------------------
# Shared verify helpers (async + sync paths both use these)
# ---------------------------------------------------------------------------
def _import_authenticate_request_options():
    """Import ``AuthenticateRequestOptions`` across clerk-backend-api layouts."""
    try:
        from clerk_backend_api import AuthenticateRequestOptions  # type: ignore
    except ImportError:
        try:
            from clerk_backend_api.security.authenticaterequest import AuthenticateRequestOptions  # type: ignore
        except ImportError:
            from clerk_backend_api.security.types import AuthenticateRequestOptions  # type: ignore
    return AuthenticateRequestOptions


def _verify_cache_key(
    headers: Mapping[str, str],
    cookies: Optional[Mapping[str, str]],
    bearer_token: Optional[str],
) -> str:
    """Stable cache key derived from the auth header / cookies / bearer."""
    cookie_str = "; ".join(f"{k}={v}" for k, v in sorted((cookies or {}).items()))
    auth_hdr = headers.get("authorization") or headers.get("Authorization") or ""
    return f"{auth_hdr}|{cookie_str}|{bearer_token or ''}"


def _is_missing_session_token(reason) -> bool:
    """True for the "no session token at all" reject family.

    Clerk session JWTs rotate every ~60s; between rotations (idle tabs,
    fresh navigations) requests legitimately arrive with no ``__session``
    cookie, and a verify is rejected with ``SESSION_TOKEN_MISSING``. That is
    an expected idle state — logging it at INFO reads like a failure and
    sends investigations down the wrong path.
    """
    name = getattr(reason, "name", "") or ""
    text = str(reason or "")
    return (
        "SESSION_TOKEN_MISSING" in name
        or "SESSION_TOKEN_MISSING" in text
        or "session-token-missing" in text
        or "session-token-and-uat-missing" in text
    )


def _log_clerk_reject(request_state, headers: Mapping[str, str], url: str) -> None:
    """Log a Clerk rejection, with a KID-mismatch hint when relevant.

    Logs at INFO, except the missing-session-token family which is an
    expected idle state (see :func:`_is_missing_session_token`) and logs
    at DEBUG. Shared by the async and sync verify paths. Common
    ``reason`` values:
      "token-expired" — JWT past its exp; client should refresh
      "token-not-active-yet" — clock skew between client and server
      "session-token-and-uat-missing" — no __session and no __client_uat
      "uat-missing" — Clerk JS hasn't finished its dev-mode bootstrap yet
      "JWK_KID_MISMATCH" — JWT signed by a key the JWKS doesn't have (usually
        CLERK_SECRET_KEY belongs to a different Clerk app than the publishable
        key, or a stale __session from a prior instance)
      "primary-respond-with-handshake" — Clerk wants a handshake redirect
    """
    reason = getattr(request_state, "reason", None)
    message = getattr(request_state, "message", "")
    kid_hint = ""
    try:
        if "KID_MISMATCH" in str(reason) or "kid" in (message or "").lower():
            cookie_str = headers.get("cookie") or headers.get("Cookie") or ""
            jwt = ""
            for item in cookie_str.split(";"):
                name, _, value = item.strip().partition("=")
                if name == "__session":
                    jwt = value
                    break
            if jwt and jwt.count(".") == 2:
                import base64 as _b64
                import json as _json
                head = jwt.split(".", 1)[0]
                head += "=" * (-len(head) % 4)
                try:
                    decoded = _json.loads(_b64.urlsafe_b64decode(head))
                    kid_hint = (
                        f" (JWT header kid={decoded.get('kid')!r}; "
                        "compare against the kids returned by Clerk's JWKS — "
                        "if this kid isn't in JWKS, your CLERK_SECRET_KEY is "
                        "likely from a different Clerk app than your "
                        "CLERK_PUBLISHABLE_KEY, OR the browser is sending a "
                        "stale __session from a prior instance — clear cookies "
                        "and re-sign-in to confirm.)"
                    )
                except Exception:
                    pass
    except Exception:
        pass
    level = logging.DEBUG if _is_missing_session_token(reason) else logging.INFO
    logger.log(
        level,
        "Clerk verify rejected: reason=%s message=%s url=%s%s",
        reason, message, url, kid_hint,
    )


def _request_state_to_user(
    request_state, *, billing_enabled: bool
) -> Optional[Tuple[ClerkUser, float]]:
    """Project a signed-in Clerk request_state to ``(user, jti_cache_ttl)``.

    Returns ``None`` if the payload had no ``sub``. The TTL is
    ``min(5 min, exp - now)`` so a cached verdict is never served past JWT
    expiry.
    """
    payload = getattr(request_state, "payload", None) or {}
    try:
        user = ClerkUser.from_jwt_payload(payload, billing_enabled=billing_enabled)
    except ValueError:
        logger.warning("Clerk verify returned signed-in but payload had no 'sub'")
        return None
    exp = payload.get("exp")
    ttl = 300.0
    if isinstance(exp, (int, float)):
        ttl = max(1.0, min(ttl, float(exp) - time.time()))
    return user, ttl


async def _acall_with_reconnect(coro_factory: Callable[[], Awaitable[Any]], *, label: str):
    """Await ``coro_factory()``; on a closed-loop error rebuild + retry once.

    The safety net for the Dash 4.2 cross-loop hazard: if the process-cached
    async Clerk client's pool bound to a now-closed loop, drop the singleton
    and try again on a fresh client. Non-loop errors propagate unchanged.
    """
    try:
        return await coro_factory()
    except Exception as exc:
        if not _is_closed_loop_error(exc):
            raise
        logger.info(
            "%s: async Clerk client hit a closed event loop; rebuilding and retrying once.",
            label,
        )
        get_async_client.cache_clear()
        return await coro_factory()


async def averify_request(
    *,
    method: str = "GET",
    url: str = "http://localhost/",
    headers: Mapping[str, str],
    cookies: Optional[Mapping[str, str]] = None,
    bearer_token: Optional[str] = None,
    authorized_parties: Optional[List[str]] = None,
    billing_enabled: bool = False,
    timeout: float = 5.0,
) -> Optional[ClerkUser]:
    """Verify a request against Clerk and return a :class:`ClerkUser` or ``None``.

    - Caches verified-positive verdicts by JWT ``jti`` for 5 minutes
      (or until JWT ``exp``, whichever is sooner).
    - Returns ``None`` on negative verdict OR transient failure within
      ``timeout`` seconds — callers decide whether to fail open/closed.

    Intended for the **main event loop** (ASGI middleware, WS connect/message
    hooks). To verify from inside a WS callback body or a job-worker thread,
    use :func:`verify_user_sync` instead — the async client's pool binds to
    whatever loop first touches it and breaks under Dash 4.2's per-callback
    ``asyncio.run()`` model.
    """
    cache_key = _verify_cache_key(headers, cookies, bearer_token)
    cached = _jti_cache.get_sync(cache_key)
    if cached is not None:
        return cached

    options = _import_authenticate_request_options()(
        authorized_parties=authorized_parties or None
    )
    request = _build_httpx_request(method, url, headers, cookies, bearer_token=bearer_token)

    async def _do():
        client = get_async_client()
        return await asyncio.wait_for(
            client.authenticate_request_async(request, options),
            timeout=timeout,
        )

    try:
        request_state = await _acall_with_reconnect(_do, label="averify_request")
    except asyncio.TimeoutError:
        logger.warning("Clerk averify_request timed out after %.1fs", timeout)
        return None
    except Exception as exc:
        logger.warning("Clerk averify_request failed: %s", exc)
        return None

    if not getattr(request_state, "is_signed_in", False):
        _log_clerk_reject(request_state, headers, url)
        return None

    result = _request_state_to_user(request_state, billing_enabled=billing_enabled)
    if result is None:
        return None
    user, ttl = result
    # Enrich BEFORE caching so the jti cache (and every __dca_identity mint
    # downstream) carries the email — see the enrichment section above.
    user = await aenrich_user(user)
    _jti_cache.put(cache_key, user, ttl=ttl)
    return user


async def aget_user_by_id(
    user_id: str,
    *,
    ttl_seconds: float = 60.0,
    force: bool = False,
) -> Optional[Dict[str, Any]]:
    """Fetch a Clerk user by id; cached, single-flight.

    **Main event loop only.** Like the rest of the ``a*`` surface this is backed
    by a loop-bound TTL cache; from a Dash 4.2 WS callback body or a worker
    thread use :func:`get_user_by_id_sync` instead.
    """

    async def _load():
        async def _do():
            return await get_async_client().users.get_async(user_id=user_id)

        try:
            user = await _acall_with_reconnect(_do, label=f"aget_user_by_id({user_id})")
        except Exception as exc:
            logger.warning("aget_user_by_id(%s) failed: %s", user_id, exc)
            return None
        return _serialize_user(user)

    return await _user_cache.get_or_load(
        ("user", user_id), _load, ttl=ttl_seconds, force=force
    )


async def alist_users_cached(
    *,
    limit: int = 100,
    order_by: str = "-created_at",
    ttl_seconds: float = 60.0,
    force: bool = False,
) -> List[Dict[str, Any]]:
    """List Clerk users; cached for ``ttl_seconds``, single-flight under load.

    Use ``force=True`` for an explicit refresh button. Calling with
    ``force=True`` from initial render is the foot-gun the v0.5 spec
    docs name explicitly — don't.

    **Main event loop only** (loop-bound TTL cache). From a Dash 4.2 WS
    callback body or a worker thread use :func:`list_users_sync` instead.
    """

    async def _load():
        async def _do():
            return await get_async_client().users.list_async(
                request={"limit": limit, "order_by": order_by}
            )

        try:
            users = await _acall_with_reconnect(_do, label="alist_users_cached")
        except Exception as exc:
            logger.warning("alist_users_cached failed: %s", exc)
            return []
        return [_serialize_user(u) for u in (users or [])]

    return await _user_list_cache.get_or_load(
        ("list", limit, order_by), _load, ttl=ttl_seconds, force=force
    )


def _serialize_user(user) -> Dict[str, Any]:
    """Project a Clerk SDK user object to a plain dict (JSON-safe)."""
    if user is None:
        return {}
    if isinstance(user, dict):
        return user
    emails = getattr(user, "email_addresses", []) or []
    return {
        "id": getattr(user, "id", None),
        "first_name": getattr(user, "first_name", None),
        "last_name": getattr(user, "last_name", None),
        "image_url": getattr(user, "image_url", None),
        "email": emails[0].email_address if emails else None,
        "email_addresses": [
            {"email_address": getattr(e, "email_address", None)} for e in emails
        ],
        "public_metadata": getattr(user, "public_metadata", {}) or {},
        "created_at": getattr(user, "created_at", None),
        "last_sign_in_at": getattr(user, "last_sign_in_at", None),
    }


# ---------------------------------------------------------------------------
# Synchronous, loop-free helpers — SAFE inside Dash 4.2 WS callback bodies
# ---------------------------------------------------------------------------
# Dash 4.2 runs each WebSocket-served callback via ``asyncio.run()`` in a
# rotating thread-pool worker (``dash/backends/ws.py::run_callback_in_executor``),
# creating and tearing down a fresh event loop per call. A process-cached
# ``httpx.AsyncClient`` (what the async helpers above use) binds its connection
# pool to the first loop that touches it, so reusing it from a later worker
# raises ``RuntimeError: Event loop is closed``. These sync helpers use
# :func:`get_sync_client` (an ``httpx.Client``, never bound to a loop), so they
# are correct from ANY thread — WS callback bodies, ``jobs.py`` daemon threads,
# APScheduler jobs. Identity inside a callback should normally come from
# ``current_user()`` (the WS registry); reach for ``verify_user_sync`` only
# when you must re-verify a raw token/cookie server-side.


def verify_user_sync(
    *,
    method: str = "GET",
    url: str = "http://localhost/",
    headers: Mapping[str, str],
    cookies: Optional[Mapping[str, str]] = None,
    bearer_token: Optional[str] = None,
    authorized_parties: Optional[List[str]] = None,
    billing_enabled: bool = False,
) -> Optional[ClerkUser]:
    """Synchronous Clerk verification — the loop-free twin of :func:`averify_request`.

    Returns a :class:`ClerkUser` on a positive verdict, else ``None`` (negative
    or transient failure). Verdicts are cached by the same key as the async
    path, in a thread-safe cache, for ``min(5 min, JWT exp)``. Safe to call
    from a Dash 4.2 WS callback worker thread or any job thread.
    """
    cache_key = _verify_cache_key(headers, cookies, bearer_token)
    cached = _sync_jti_cache.get(cache_key)
    if cached is not None:
        return cached

    options = _import_authenticate_request_options()(
        authorized_parties=authorized_parties or None
    )
    request = _build_httpx_request(method, url, headers, cookies, bearer_token=bearer_token)

    try:
        request_state = get_sync_client().authenticate_request(request, options)
    except Exception as exc:
        logger.warning("Clerk verify_user_sync failed: %s", exc)
        return None

    if not getattr(request_state, "is_signed_in", False):
        _log_clerk_reject(request_state, headers, url)
        return None

    result = _request_state_to_user(request_state, billing_enabled=billing_enabled)
    if result is None:
        return None
    user, ttl = result
    # Enrich BEFORE caching so the jti cache (and every __dca_identity mint
    # downstream) carries the email — see the enrichment section above.
    user = enrich_user_sync(user)
    _sync_jti_cache.put(cache_key, user, ttl=ttl)
    return user


def get_user_by_id_sync(
    user_id: str,
    *,
    ttl_seconds: float = 60.0,
    force: bool = False,
) -> Optional[Dict[str, Any]]:
    """Fetch a Clerk user by id (sync, cached). Loop-free twin of :func:`aget_user_by_id`."""
    key = ("user", user_id)
    if not force:
        cached = _sync_user_cache.get(key)
        if cached is not None:
            return cached
    try:
        user = get_sync_client().users.get(user_id=user_id)
    except Exception as exc:
        logger.warning("get_user_by_id_sync(%s) failed: %s", user_id, exc)
        return None
    data = _serialize_user(user)
    _sync_user_cache.put(key, data, ttl=ttl_seconds)
    return data


def list_users_sync(
    *,
    limit: int = 100,
    order_by: str = "-created_at",
    ttl_seconds: float = 60.0,
    force: bool = False,
) -> List[Dict[str, Any]]:
    """List Clerk users (sync, cached). Loop-free twin of :func:`alist_users_cached`.

    Use ``force=True`` only for an explicit refresh button, never on first render.
    """
    key = ("list", limit, order_by)
    if not force:
        cached = _sync_user_list_cache.get(key)
        if cached is not None:
            return cached
    try:
        users = get_sync_client().users.list(
            request={"limit": limit, "order_by": order_by}
        )
    except Exception as exc:
        logger.warning("list_users_sync failed: %s", exc)
        return []
    data = [_serialize_user(u) for u in (users or [])]
    _sync_user_list_cache.put(key, data, ttl=ttl_seconds)
    return data


def set_user_role_sync(user_id: str, role: str) -> Optional[Dict[str, Any]]:
    """Set ``public_metadata.role`` on a Clerk user (sync, loop-free, merge-patch).

    This is the exact "admin saves a role" WS-callback case the cross-loop
    hazard breaks when app code awaits the async client from a worker thread.
    Uses Clerk's ``update_metadata`` (PATCH/merge) so other ``public_metadata``
    keys are preserved. Invalidates the user + user-list caches on success and
    returns the updated user dict, or ``None`` on failure.
    """
    try:
        user = get_sync_client().users.update_metadata(
            user_id=user_id, public_metadata={"role": role}
        )
    except Exception as exc:
        logger.warning("set_user_role_sync(%s, %s) failed: %s", user_id, role, exc)
        return None
    _sync_user_cache.invalidate(("user", user_id))
    _sync_user_list_cache.clear()
    return _serialize_user(user)
