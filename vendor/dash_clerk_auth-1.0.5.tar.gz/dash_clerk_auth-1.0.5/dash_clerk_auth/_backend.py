"""Backend-neutral identity dispatcher.

``current_user()`` is the universal read for "who is this request from?".
It walks a precedence chain so the same call works on every supported
combination of Dash backend (Flask/FastAPI/Quart) and transport (HTTP/WS):

1. The asyncio-friendly :class:`ContextVar` populated by
   :class:`dash_clerk_auth._asgi.ClerkASGIMiddleware` on HTTP scope and
   by the optional Dash 4.2 WebSocket connect hook.
2. The per-renderer WebSocket registry (:mod:`._ws_registry`). Necessary
   because Dash 4.2 dispatches WS callbacks through a thread pool that
   does not propagate ``ContextVar`` state from the asyncio task.
3. Flask ``g.clerk_user`` (set by the ``before_request`` hook).
4. Flask ``session`` reconstruction (legacy v0.5).
5. ``None`` — anonymous or outside any request scope.

Decorators, layout helpers and callback bodies depend ONLY on this
module — they never branch on backend or transport.
"""

from __future__ import annotations

import logging
from contextvars import ContextVar
from typing import Optional

from ._user import ClerkUser
from ._ws_registry import lookup as _ws_lookup, renderer_id_from_callback_context

logger = logging.getLogger(__name__)

# ContextVar drives FastAPI/Starlette/Quart paths and any explicit set by
# the WebSocket connect hook. Default None = anonymous request.
_CURRENT_USER: ContextVar[Optional[ClerkUser]] = ContextVar(
    "dash_clerk_auth.current_user", default=None
)

# Soft Flask import: package must load without Flask installed (FastAPI-only deploys).
try:
    from flask import g, has_request_context, session  # type: ignore
    _FLASK_AVAILABLE = True
except ImportError:  # pragma: no cover — exercised only on Flask-less installs
    g = None  # type: ignore
    has_request_context = None  # type: ignore
    session = None  # type: ignore
    _FLASK_AVAILABLE = False


def _from_ws_registry() -> Optional[ClerkUser]:
    """Read the user via the active WS callback's renderer_id."""
    rid = renderer_id_from_callback_context()
    if rid is None:
        return None
    return _ws_lookup(rid)


def _from_flask_request_context() -> Optional[ClerkUser]:
    """Read the user out of the active Flask request, if any."""
    if not _FLASK_AVAILABLE or has_request_context is None:
        return None
    try:
        if not has_request_context():
            return None
    except RuntimeError:
        return None

    # Fast path — populated by our before_request hook.
    user = getattr(g, "clerk_user", None)
    if isinstance(user, ClerkUser):
        return user

    # v0.5 compatibility — reconstruct from the Flask session dict if a
    # caller wrote there directly (legacy code) but never went through
    # our before_request hook.
    if session is not None:
        try:
            return ClerkUser.from_session_dict(session)
        except RuntimeError:
            return None
        except Exception as exc:  # pragma: no cover — defensive
            logger.debug("ClerkUser session reconstruction failed: %s", exc)
    return None


def current_user() -> Optional[ClerkUser]:
    """Return the verified Clerk user for THIS request, or ``None``.

    Backend-neutral, transport-neutral. Reads in priority order:

    1. The asyncio-friendly :class:`ContextVar` (set by the FastAPI
       middleware OR the optional Dash 4.2 WebSocket connect hook).
    2. The per-renderer WS registry — only relevant inside a Dash 4.2
       WS-served callback.
    3. Flask ``g.clerk_user`` (set by the ``before_request`` hook
       installed by ``register_clerk_auth(backend="flask")``).
    4. The legacy v0.5 ``flask.session`` dict — for callers who wrote
       there directly. Reconstructs a ``ClerkUser`` lossily.

    Returns ``None`` when called outside any request scope.
    """
    user = _CURRENT_USER.get()
    if user is not None:
        return user
    user = _from_ws_registry()
    if user is not None:
        return user
    return _from_flask_request_context()


def callback_user() -> Optional[ClerkUser]:
    """Alias of :func:`current_user` — clearer intent at callback call sites."""
    return current_user()


def is_authenticated() -> bool:
    """``True`` iff a verified Clerk session is bound to this request."""
    return current_user() is not None


def set_request_user(user: Optional[ClerkUser]):
    """Bind ``user`` as the current request's identity.

    Returns the ContextVar token so callers can ``reset()`` it during
    cleanup. Used by the ASGI middleware and the WebSocket connect hook.
    Application code should not call this directly.
    """
    return _CURRENT_USER.set(user)


def reset_request_user(token) -> None:
    """Reset the ContextVar to the value before ``set_request_user``."""
    try:
        _CURRENT_USER.reset(token)
    except (LookupError, ValueError):
        # Token from a different context — safe to ignore in cleanup paths.
        pass


def detect_backend(server) -> str:
    """Best-effort backend detection from a Dash ``app.server``.

    Returns one of ``"flask"``, ``"fastapi"``, ``"quart"``, ``"unknown"``.
    Never raises; returns ``"unknown"`` rather than failing.
    """
    if server is None:
        return "unknown"

    # FastAPI is a Starlette subclass — check both, preferring the more
    # specific name for logging clarity.
    cls_chain = type(server).__mro__
    cls_names = {cls.__module__ + "." + cls.__name__ for cls in cls_chain}

    if any(n.startswith("fastapi.") for n in cls_names):
        return "fastapi"
    if any(n.startswith("starlette.") for n in cls_names):
        return "fastapi"
    if any(n.startswith("quart.") for n in cls_names):
        return "quart"
    if any(n.startswith("flask.") for n in cls_names):
        return "flask"

    # Duck-type fallback — Flask exposes before_request; ASGI apps don't.
    if hasattr(server, "before_request") and hasattr(server, "route"):
        return "flask"
    if callable(server):
        # ASGI apps are callables with __call__(scope, receive, send).
        return "fastapi"
    return "unknown"
