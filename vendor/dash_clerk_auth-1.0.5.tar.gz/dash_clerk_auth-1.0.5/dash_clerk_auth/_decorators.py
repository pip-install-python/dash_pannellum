"""Layout-level gating decorators.

These commit to one branch *server-side* before any callback fires, so a
heavy admin layout never builds for an anonymous visitor. They work
identically on Flask and FastAPI because they read identity through
:func:`dash_clerk_auth._backend.current_user`, which dispatches based on
the active request scope.

Three policies for the unverified case:

- ``"forbidden"`` (default, fail-closed): return the placeholder. This
  is what a production outage postmortem named as the right default — it
  closes the "render both, let the client decide" foot-gun that masks
  worker hangs.
- ``"allow"``: render the protected layout anyway. Use only when the
  layout is cheap and the gate is purely cosmetic.
- ``"passthrough"``: legacy v0.5 behaviour — render the placeholder AND
  expose the protected layout for client-side gating to hide. Kept for
  callers explicitly opting in.
"""

from __future__ import annotations

import logging
from functools import wraps
from typing import Any, Callable, Iterable, Optional, Union

from dash import html

from ._backend import current_user
from ._user import ClerkUser

logger = logging.getLogger(__name__)

LayoutValue = Union[Callable[..., Any], Any]
"""A Dash layout — either a ``def layout()`` function or a value (component / list)."""


_DEFAULT_FORBIDDEN_STYLE = {
    "padding": "48px 24px",
    "maxWidth": "520px",
    "margin": "10vh auto",
    "textAlign": "center",
    "fontFamily": '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    "borderRadius": "16px",
    "background": "var(--clerk-glass-bg, rgba(255,255,255,0.75))",
    "backdropFilter": "blur(24px) saturate(180%)",
    "WebkitBackdropFilter": "blur(24px) saturate(180%)",
    "border": "1px solid var(--clerk-border, rgba(0,0,0,0.08))",
    "boxShadow": "var(--clerk-shadow-md, 0 4px 16px rgba(0,0,0,0.06))",
    "color": "var(--clerk-text, #2c3e50)",
}


def default_forbidden_layout(message: str = "Sign in required") -> Any:
    """A small, dependency-free liquid-glass placeholder.

    Used when callers don't pass a custom ``forbidden=`` placeholder.
    Plain ``dash.html`` so we don't drag in ``dash_mantine_components``
    transitively — apps that want a richer look should pass their own.
    """
    return html.Div(
        [
            html.Div("🔒", style={"fontSize": "40px", "marginBottom": "12px"}),
            html.H3(message, style={"margin": "0 0 8px", "fontWeight": 600}),
            html.P(
                "You don't have access to this page.",
                style={
                    "margin": 0,
                    "fontSize": "14px",
                    "color": "var(--clerk-text-secondary, #6c757d)",
                },
            ),
        ],
        style=_DEFAULT_FORBIDDEN_STYLE,
    )


def _resolve_forbidden(forbidden: Optional[LayoutValue], message: str) -> Any:
    if forbidden is None:
        return default_forbidden_layout(message)
    if callable(forbidden):
        try:
            return forbidden()
        except Exception as exc:
            logger.warning("Custom forbidden placeholder raised %s; using default", exc)
            return default_forbidden_layout(message)
    return forbidden


def _wrap_layout(
    layout: LayoutValue,
    *,
    predicate: Callable[[Optional[ClerkUser]], bool],
    forbidden: Optional[LayoutValue],
    on_inconclusive: str,
    forbidden_message: str,
) -> LayoutValue:
    """Wrap a Dash layout (callable or value) with a server-side gate.

    Returns a callable that Dash invokes per-render. Even when the
    original layout was a constant value, we wrap it in a callable so
    the gate runs on every render, not once at import.
    """
    if on_inconclusive not in {"forbidden", "allow", "passthrough"}:
        raise ValueError(
            f"on_inconclusive must be 'forbidden' | 'allow' | 'passthrough', got {on_inconclusive!r}"
        )

    @wraps(layout if callable(layout) else lambda: None)
    def _gated(*args, **kwargs):
        user = current_user()
        allowed = predicate(user) if user is not None else False

        if allowed:
            return layout(*args, **kwargs) if callable(layout) else layout

        # Not allowed. Branch on the inconclusive policy when we couldn't
        # verify identity (user is None). For an authenticated user who
        # simply lacks the role/plan/feature, ALWAYS show forbidden —
        # that's a deterministic "no", not an inconclusive verdict.
        if user is None and on_inconclusive == "allow":
            return layout(*args, **kwargs) if callable(layout) else layout
        if user is None and on_inconclusive == "passthrough":
            # Render both: the protected layout AND the placeholder. Lets
            # client-side gates hide one of them. Legacy behaviour.
            protected = layout(*args, **kwargs) if callable(layout) else layout
            placeholder = _resolve_forbidden(forbidden, forbidden_message)
            return html.Div([placeholder, html.Div(protected, style={"display": "none"})])

        return _resolve_forbidden(forbidden, forbidden_message)

    return _gated


# ---------------------------------------------------------------------------
# Public decorators
# ---------------------------------------------------------------------------
def require_auth_layout(
    forbidden: Optional[LayoutValue] = None,
    *,
    on_inconclusive: str = "forbidden",
    message: str = "Sign in required",
):
    """Gate a Dash layout on "any signed-in user"."""

    def _decorator(layout: LayoutValue) -> LayoutValue:
        return _wrap_layout(
            layout,
            predicate=lambda u: u is not None,
            forbidden=forbidden,
            on_inconclusive=on_inconclusive,
            forbidden_message=message,
        )

    return _decorator


def require_role_layout(
    role: str,
    forbidden: Optional[LayoutValue] = None,
    *,
    on_inconclusive: str = "forbidden",
    message: Optional[str] = None,
):
    """Gate a Dash layout on ``user.role == role`` (case-insensitive)."""
    needed = role.lower()
    msg = message or f"{role.capitalize()} access required"

    def _decorator(layout: LayoutValue) -> LayoutValue:
        return _wrap_layout(
            layout,
            predicate=lambda u: bool(u and u.has_role(needed)),
            forbidden=forbidden,
            on_inconclusive=on_inconclusive,
            forbidden_message=msg,
        )

    return _decorator


def require_plan_layout(
    plans: Union[str, Iterable[str]],
    forbidden: Optional[LayoutValue] = None,
    *,
    on_inconclusive: str = "forbidden",
    message: Optional[str] = None,
):
    """Gate a Dash layout on ``user.plan`` matching one of ``plans``."""
    if isinstance(plans, str):
        plan_list = [plans]
    else:
        plan_list = [p for p in plans]
    msg = message or "Upgrade required"

    def _decorator(layout: LayoutValue) -> LayoutValue:
        return _wrap_layout(
            layout,
            predicate=lambda u: bool(u and u.has_plan(plan_list)),
            forbidden=forbidden,
            on_inconclusive=on_inconclusive,
            forbidden_message=msg,
        )

    return _decorator


def require_feature_layout(
    feature: str,
    forbidden: Optional[LayoutValue] = None,
    *,
    on_inconclusive: str = "forbidden",
    message: Optional[str] = None,
):
    """Gate a Dash layout on ``feature`` being in ``user.features``."""
    msg = message or "Feature not available"

    def _decorator(layout: LayoutValue) -> LayoutValue:
        return _wrap_layout(
            layout,
            predicate=lambda u: bool(u and u.has_feature(feature)),
            forbidden=forbidden,
            on_inconclusive=on_inconclusive,
            forbidden_message=msg,
        )

    return _decorator
