"""FastAPI / Starlette configurer.

Mirrors the Flask-side ``configure_app()`` for the ASGI world. Installs:

- :class:`ClerkASGIMiddleware` so every HTTP request **and** WebSocket
  upgrade gets a verified ``ClerkUser`` (or ``None``) bound to the
  ContextVar / scope state. The middleware also mints the
  ``__dca_identity`` cookie on successful Clerk verifies so subsequent
  requests skip the JWKS roundtrip.
- A signed-cookie session via Starlette ``SessionMiddleware`` (the same
  ``session_secret`` powers the identity cookie, kept in lockstep so a
  redeploy invalidates both consistently).
- ``POST /api/auth/session`` and ``POST /api/auth/signout`` endpoints
  that match the Flask-side surface byte-for-byte. ``/session`` mints
  the ``__dca_identity`` cookie alongside the session write; ``/signout``
  clears it.

All Starlette imports happen lazily so a Flask-only deploy never has to
install starlette.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from ._asgi import ClerkASGIMiddleware
from ._identity_cookie import (
    bounded_max_age,
    flask_set_cookie_kwargs as _flask_set_cookie_kwargs,  # noqa: F401 — kept exported for callers
    mint as _mint_identity,
    set_cookie_header as _set_identity_cookie_header,
    clear_cookie_header as _clear_identity_cookie_header,
)
from ._user import ClerkUser

# Imported at module scope ON PURPOSE, guarded. `from __future__ import
# annotations` makes every annotation a string, and FastAPI resolves handler
# annotations with typing.get_type_hints() against the MODULE globals — a
# function-local import would not be visible to it, and the handlers would go
# back to being unreachable. This module is only ever imported from the ASGI
# configurer, so starlette is present in practice; the guard keeps a bare
# `import dash_clerk_auth._fastapi` working for introspection without it.
try:
    from starlette.requests import Request
except ImportError:  # pragma: no cover — no starlette means no ASGI backend
    Request = Any

logger = logging.getLogger(__name__)


def configure_fastapi_app(
    app,
    *,
    clerk_secret_key: str,
    session_secret: str,
    session_lifetime_days: int = 7,
    billing_enabled: bool = False,
    authorized_parties: Optional[list] = None,
    on_unverified: str = "forbidden",
    verify_timeout: float = 5.0,
) -> None:
    """Configure a Dash 4 ``backend="fastapi"`` (or Quart) app for Clerk auth.

    :param app: a Dash app instance whose ``app.server`` is a FastAPI /
        Starlette / Quart application.
    """
    server = app.server
    if server is None:
        raise RuntimeError("Dash app has no .server — cannot configure ASGI middleware.")

    # Lazy imports so Flask-only deploys never need starlette installed.
    try:
        from starlette.middleware.sessions import SessionMiddleware
    except ImportError as exc:
        raise RuntimeError(
            "dash_clerk_auth backend='fastapi'/'quart' requires starlette. "
            "Install with: pip install starlette itsdangerous"
        ) from exc

    identity_cookie_max_age = session_lifetime_days * 24 * 60 * 60

    # 1. Signed-cookie session (Starlette uses itsdangerous under the hood).
    server.add_middleware(
        SessionMiddleware,
        secret_key=session_secret,
        max_age=identity_cookie_max_age,
        same_site="lax",
        https_only=False,  # leave to deployer; LB will set X-Forwarded-Proto
        session_cookie="dash_clerk_session",
    )

    # 2. Clerk verification middleware. Added AFTER SessionMiddleware so
    # SessionMiddleware sees the request first and Clerk middleware runs
    # closer to the app — Starlette runs middleware in REVERSE add order
    # for inbound requests, so the order here means: Session → Clerk → app.
    server.add_middleware(
        ClerkASGIMiddleware,
        session_secret=session_secret,
        identity_cookie_max_age=identity_cookie_max_age,
        authorized_parties=authorized_parties,
        billing_enabled=billing_enabled,
        on_unverified=on_unverified,
        verify_timeout=verify_timeout,
    )

    # 3. Auth endpoints — match the Flask-side surface so frontend code
    # can hit /api/auth/session and /api/auth/signout regardless of backend.
    _mount_auth_routes(
        server,
        clerk_secret_key=clerk_secret_key,
        session_secret=session_secret,
        identity_cookie_max_age=identity_cookie_max_age,
        billing_enabled=billing_enabled,
        authorized_parties=authorized_parties,
    )

    logger.info("dash-clerk-auth FastAPI/Starlette backend configured")


def _mount_auth_routes(
    server,
    *,
    clerk_secret_key: str,
    session_secret: str,
    identity_cookie_max_age: int,
    billing_enabled: bool,
    authorized_parties: Optional[list],
) -> None:
    """Mount /api/auth/session and /api/auth/signout on the ASGI server."""

    # Try FastAPI's typed APIRoute decorators first; fall back to plain
    # Starlette routing if the server is a bare Starlette app.
    is_fastapi = type(server).__module__.startswith("fastapi.")

    from ._clerk_client import averify_request

    async def _session_handler(request: Request) -> Any:
        try:
            data = await request.json()
        except Exception:
            data = {}
        token = (data or {}).get("token")
        if not token:
            return _json_response({"authenticated": False, "error": "No token provided"}, status_code=401)

        # Build headers/cookies dicts to feed averify_request.
        headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in request.scope.get("headers", [])}
        cookies = dict(request.cookies or {})

        user: Optional[ClerkUser] = await averify_request(
            method=request.method,
            url=str(request.url),
            headers=headers,
            cookies=cookies,
            bearer_token=token,
            authorized_parties=authorized_parties,
            billing_enabled=billing_enabled,
        )

        if user is None:
            return _json_response({"authenticated": False, "error": "Authentication failed"}, status_code=401)

        # Persist to the signed-cookie session for v0.5-compatible reads.
        try:
            request.session.update(user.to_session_dict())
        except Exception:  # SessionMiddleware not installed for some reason.
            pass

        # Mint the __dca_identity cookie so subsequent HTTP/WS requests
        # skip the Clerk roundtrip. TTL bounded by JWT exp.
        response = _json_response({"authenticated": True, "user": user.to_session_dict()})
        _attach_identity_cookie(
            response,
            user,
            session_secret=session_secret,
            max_age_cap=identity_cookie_max_age,
            secure=_is_https(request),
        )
        return response

    async def _signout_handler(request: Request) -> Any:
        try:
            request.session.clear()
        except Exception:
            pass
        response = _json_response({"success": True})
        _attach_identity_cookie_clear(response, secure=_is_https(request))
        return response

    if is_fastapi:
        # FastAPI: the @app.post decorator, so these appear in OpenAPI.
        #
        # The `request: Request` annotations above are load-bearing, not
        # decoration. FastAPI inspects the signature and resolves any
        # parameter it does not recognise as a **query** field — required,
        # since there is no default. An unannotated `request` therefore made
        # every POST fail with 422 before the handler ran, on every FastAPI
        # deployment since these endpoints existed. Nothing caught it because
        # the client fires them fire-and-forget, so the only visible symptom
        # was sign-out silently not revoking server-side.
        # tests/test_fastapi_auth_routes.py calls both routes for real.
        server.post("/api/auth/session")(_session_handler)
        server.post("/api/auth/signout")(_signout_handler)
    else:
        # Starlette: append to the routing table.
        from starlette.routing import Route

        server.routes.append(Route("/api/auth/session", _session_handler, methods=["POST"]))
        server.routes.append(Route("/api/auth/signout", _signout_handler, methods=["POST"]))


def _json_response(body, *, status_code: int = 200):
    from starlette.responses import JSONResponse

    return JSONResponse(body, status_code=status_code)


def _is_https(request) -> bool:
    """Honour proxy headers so cookies are ``Secure`` behind a TLS LB."""
    if request.url.scheme == "https":
        return True
    proto = request.headers.get("x-forwarded-proto", "")
    return proto.lower().startswith("https")


def _attach_identity_cookie(
    response,
    user: ClerkUser,
    *,
    session_secret: str,
    max_age_cap: int,
    secure: bool,
) -> None:
    """Append a ``Set-Cookie: __dca_identity=...`` header to the response.

    Uses ``max_age_cap`` directly (NOT JWT ``exp``). Clerk session JWTs
    rotate every ~60s on dev keys; bounding the cookie to the JWT's
    lifetime would mean it expires almost immediately. The cookie's job
    is to cache the *identity* across many JWT refreshes, with its own
    HMAC signature gating freshness on every read.
    """
    if not session_secret:
        return
    token = _mint_identity(user, session_secret)
    name, value = _set_identity_cookie_header(
        token,
        max_age=max(60, int(max_age_cap)),
        secure=secure,
        same_site="Lax",
    )
    response.raw_headers.append((name, value))


def _attach_identity_cookie_clear(response, *, secure: bool) -> None:
    name, value = _clear_identity_cookie_header(secure=secure)
    response.raw_headers.append((name, value))
