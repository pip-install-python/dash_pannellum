"""ASGI middleware that verifies Clerk sessions on FastAPI / Starlette / Quart.

Wraps the Dash ``app.server`` (an ASGI app on Dash 4 ``backend="fastapi"``).
Runs on **both HTTP and WebSocket scopes** so Dash 4.2's WebSocket-served
callbacks see the same identity that HTTP callbacks do.

Identity resolution per request:

1. **Fast path:** if the ``__dca_identity`` cookie is present and verifies,
   use it. Microsecond HMAC verify, no I/O.
2. **Slow path:** if only the Clerk ``__session`` cookie (or a bearer
   token) is present, run :func:`averify_request` against Clerk's JWKS.
   On success, mint a fresh ``__dca_identity`` cookie on the response so
   the next request hits the fast path.
3. Mirror the verdict onto ``scope["state"]["clerk_user"]`` (Starlette
   exposes this as ``request.state.clerk_user`` /
   ``websocket.state.clerk_user``).
4. For HTTP scope: also bind to the per-task ContextVar via
   :func:`set_request_user` so ``current_user()`` works synchronously
   inside the callback handler.

Static asset paths and Dash's renderer-housekeeping endpoints are
skipped — no point verifying a bot pulling JS bundles.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Awaitable, Callable, Iterable, List, Optional

from ._backend import reset_request_user, set_request_user
from ._clerk_client import averify_request
from ._identity_cookie import (
    COOKIE_NAME as _IDENTITY_COOKIE,
    bounded_max_age,
    mint as _mint_identity,
    set_cookie_header as _identity_set_cookie_header,
    verify as _verify_identity,
)
from ._user import ClerkUser

logger = logging.getLogger(__name__)


# Paths we never verify — static assets, healthchecks. These are HTTP path
# *prefixes* (case-sensitive). Keep small; downstream apps can extend via
# the constructor's ``skip_paths`` kwarg.
_DEFAULT_SKIP_PREFIXES: tuple = (
    "/_dash-component-suites/",
    "/_favicon.ico",
    "/_dash-dependencies",
    "/_dash-layout",
    "/_reload-hash",
    "/assets/",
    "/static/",
    "/health",
    "/api/health",
)


def _extract_token_and_cookies(scope) -> tuple:
    """Pull the bearer token + cookie dict out of an ASGI HTTP/WS scope."""
    headers_raw = scope.get("headers") or []
    headers: dict = {}
    cookie_header = ""
    for k, v in headers_raw:
        try:
            name = k.decode("latin-1").lower()
            value = v.decode("latin-1")
        except Exception:
            continue
        headers[name] = value
        if name == "cookie":
            cookie_header = value

    cookies: dict = {}
    if cookie_header:
        for item in cookie_header.split(";"):
            if "=" in item:
                name, _, value = item.strip().partition("=")
                if name:
                    cookies[name] = value

    bearer: Optional[str] = None
    auth = headers.get("authorization") or ""
    if auth.lower().startswith("bearer "):
        bearer = auth.split(" ", 1)[1].strip()

    return headers, cookies, bearer


def _scope_url(scope) -> str:
    scheme = scope.get("scheme", "http")
    server = scope.get("server") or ("localhost", 80)
    host_header = None
    for k, v in scope.get("headers") or []:
        if k.lower() == b"host":
            host_header = v.decode("latin-1")
            break
    host = host_header or f"{server[0]}:{server[1]}"
    path = scope.get("raw_path") or scope.get("path", "/").encode("latin-1")
    if isinstance(path, bytes):
        path = path.decode("latin-1")
    qs = scope.get("query_string") or b""
    if qs:
        return f"{scheme}://{host}{path}?{qs.decode('latin-1')}"
    return f"{scheme}://{host}{path}"


def _scope_is_https(scope) -> bool:
    """Honour ``X-Forwarded-Proto`` so cookies are ``Secure`` behind a TLS LB."""
    if scope.get("scheme") == "https":
        return True
    for k, v in scope.get("headers") or []:
        if k.lower() == b"x-forwarded-proto" and v.lower().startswith(b"https"):
            return True
    return False


class ClerkASGIMiddleware:
    """ASGI middleware that verifies Clerk sessions and binds the user.

    :param app: the wrapped ASGI app (typically ``app.server`` from Dash).
    :param session_secret: secret used to sign the ``__dca_identity``
        cookie. Pass the same value as Starlette ``SessionMiddleware``'s
        ``secret_key`` so a single re-deploy rotates both consistently.
        ``None`` disables cookie minting (slow-path-every-request).
    :param identity_cookie_max_age: cap on the cookie's TTL in seconds.
        Defaults to 7 days. Always bounded by the JWT ``exp`` so we never
        outlive the underlying Clerk session.
    :param authorized_parties: Clerk ``authorized_parties`` whitelist.
    :param billing_enabled: when True, populate ``ClerkUser.plan`` /
        ``ClerkUser.features`` from the JWT.
    :param on_unverified: ``"forbidden"`` | ``"allow"`` | ``"passthrough"``.
        Drives :func:`current_user` when verification fails. ``"forbidden"``
        (default) and ``"passthrough"`` both leave the ContextVar at
        ``None``; the difference is downstream — only the layout
        decorators read this knob from config. The middleware itself
        always fails closed (no anonymous user gets ``ClerkUser``).
    :param skip_paths: extra HTTP path prefixes to skip verification for.
    :param verify_timeout: per-request Clerk verify timeout in seconds.
    """

    def __init__(
        self,
        app,
        *,
        session_secret: Optional[str] = None,
        identity_cookie_max_age: int = 7 * 24 * 3600,
        authorized_parties: Optional[List[str]] = None,
        billing_enabled: bool = False,
        on_unverified: str = "forbidden",
        skip_paths: Iterable[str] = (),
        verify_timeout: float = 5.0,
    ):
        self.app = app
        self.session_secret = session_secret
        self.identity_cookie_max_age = int(identity_cookie_max_age)
        self.authorized_parties = list(authorized_parties or [])
        self.billing_enabled = bool(billing_enabled)
        self.on_unverified = on_unverified
        self.verify_timeout = verify_timeout
        self._skip = tuple(_DEFAULT_SKIP_PREFIXES) + tuple(skip_paths)

    def _should_skip(self, scope) -> bool:
        path = scope.get("path", "")
        return any(path == p or path.startswith(p) for p in self._skip)

    async def _resolve_identity(self, scope) -> tuple:
        """Return ``(user, cookies, freshly_verified)``.

        ``freshly_verified`` is True only when we hit the slow path
        (Clerk roundtrip) and got a positive verdict — the caller uses
        that to decide whether to mint a new ``__dca_identity`` cookie.
        """
        headers, cookies, bearer = _extract_token_and_cookies(scope)
        path = scope.get("path", "?")

        # Fast path — local cookie verify.
        identity_token = cookies.get(_IDENTITY_COOKIE)
        if identity_token and self.session_secret:
            cached = _verify_identity(
                identity_token, self.session_secret, self.identity_cookie_max_age
            )
            if cached is not None:
                logger.debug(
                    "clerk-auth %s: fast-path cookie verified for user=%s",
                    path, cached.user_id,
                )
                return cached, cookies, False

        # Slow path — defer to Clerk only when there's an actual session
        # token to verify. ``__client_uat``/``__refresh_*`` without a
        # ``__session`` cookie is the expected idle state between Clerk's
        # ~60s JWT rotations: a verify is guaranteed to reject with
        # SESSION_TOKEN_MISSING, so skip the roundtrip and keep quiet.
        has_session_token = "__session" in cookies or any(
            k.startswith("__session_") for k in cookies
        )
        if not (bearer or has_session_token):
            if any(k.startswith("__client") or k.startswith("__refresh") for k in cookies):
                logger.debug(
                    "clerk-auth %s: no session token (rotated/idle) — anonymous", path
                )
            else:
                logger.debug("clerk-auth %s: anonymous (no bearer, no __session)", path)
            return None, cookies, False

        user = await averify_request(
            method=scope.get("method", "GET"),
            url=_scope_url(scope),
            headers=headers,
            cookies=cookies,
            bearer_token=bearer,
            authorized_parties=self.authorized_parties or None,
            billing_enabled=self.billing_enabled,
            timeout=self.verify_timeout,
        )
        if user is not None:
            logger.info(
                "clerk-auth %s: slow-path Clerk verify ok user=%s — minting __dca_identity",
                path, user.user_id,
            )
        else:
            logger.info(
                "clerk-auth %s: slow-path Clerk verify rejected (session token present)",
                path,
            )
        return user, cookies, user is not None

    def _build_set_cookie_header(self, user: ClerkUser, scope) -> Optional[tuple]:
        """Return a ``(b"set-cookie", b"...")`` header tuple, or ``None``.

        Note: we use ``identity_cookie_max_age`` directly — NOT the JWT
        exp. Clerk session JWTs have very short TTLs (60s on dev keys);
        bounding the cookie to the JWT exp would mean the cookie expires
        a minute after issue and falls back to the slow path constantly.
        The cookie's job is to cache the *identity* (sub/email/role/etc.)
        across many JWT refreshes, not to mirror the JWT's lifetime.
        Verification on read is via :func:`._identity_cookie.verify` which
        rejects forged or stale-by-its-own-cap-of cookies.
        """
        if not self.session_secret:
            logger.debug("identity cookie not minted: no session_secret configured")
            return None
        token = _mint_identity(user, self.session_secret)
        max_age = max(60, int(self.identity_cookie_max_age))
        return _identity_set_cookie_header(
            token,
            max_age=max_age,
            secure=_scope_is_https(scope),
            same_site="Lax",
        )

    async def _handle_http(self, scope, receive, send):
        if self._should_skip(scope):
            await self.app(scope, receive, send)
            return

        user, _cookies, freshly_verified = await self._resolve_identity(scope)

        # Mirror onto scope["state"] so downstream handlers / WS-connect
        # hooks can read without re-verifying.
        scope.setdefault("state", {})
        scope["state"]["clerk_user"] = user

        # If we hit the slow path and verified successfully, attach a
        # Set-Cookie header to the response so the next request hits the
        # fast path. Wrap ``send`` to intercept the ``http.response.start``
        # message and append our header.
        cookie_header = (
            self._build_set_cookie_header(user, scope) if freshly_verified else None
        )

        if cookie_header is not None:
            async def send_with_cookie(message):
                if message["type"] == "http.response.start":
                    headers = list(message.get("headers") or [])
                    headers.append(cookie_header)
                    message = {**message, "headers": headers}
                await send(message)
            wrapped_send = send_with_cookie
        else:
            wrapped_send = send

        token = set_request_user(user)
        try:
            await self.app(scope, receive, wrapped_send)
        finally:
            reset_request_user(token)

    async def _handle_ws(self, scope, receive, send):
        # Path skipping doesn't really apply to WS — there's exactly one
        # WS endpoint per Dash app — but honour the same list for consistency.
        if self._should_skip(scope):
            await self.app(scope, receive, send)
            return

        user, _cookies, _freshly_verified = await self._resolve_identity(scope)

        # Mirror onto scope["state"] so the WS connect/message hooks can
        # read it without re-verifying. The WS handshake response cannot
        # reliably set cookies that the renderer reads back, so we don't
        # mint here — the next HTTP request refreshes the cookie.
        scope.setdefault("state", {})
        scope["state"]["clerk_user"] = user

        token = set_request_user(user)
        try:
            await self.app(scope, receive, send)
        finally:
            reset_request_user(token)

    async def __call__(
        self,
        scope,
        receive: Callable[[], Awaitable[Any]],
        send: Callable[[Any], Awaitable[None]],
    ):
        scope_type = scope.get("type")
        if scope_type == "http":
            await self._handle_http(scope, receive, send)
        elif scope_type == "websocket":
            await self._handle_ws(scope, receive, send)
        else:
            await self.app(scope, receive, send)
