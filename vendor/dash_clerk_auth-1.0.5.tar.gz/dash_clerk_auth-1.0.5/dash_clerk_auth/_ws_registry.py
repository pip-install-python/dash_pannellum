"""Per-WebSocket-renderer identity registry.

Dash 4.2's WebSocket callbacks dispatch through a ``ThreadPoolExecutor``
(see ``dash/backends/ws.py::run_callback_in_executor``). Python's
``concurrent.futures`` does not propagate :class:`contextvars.ContextVar`
state from the submitting asyncio task to the worker thread — so the
``ContextVar`` we set in the ``websocket_connect`` hook is invisible
inside the actual callback body.

Workaround: a tiny process-global mapping from ``renderer_id`` (a UUID
generated per WebSocket connection by Dash's renderer) to the verified
``ClerkUser``. We populate it from the asyncio task in the
``websocket_message`` hook (which fires before each callback dispatch),
and read it from the worker thread inside :func:`current_user` via
``dash.callback_context.websocket._renderer_id``.

The registry is bounded by a TTL (24 h default) and a max size (4096
default). Both are intentionally generous: a typical Dash app has well
under 4096 concurrent WebSocket connections, and 24 h is far longer than
any realistic browser tab lifetime. The cleanup is opportunistic — we
sweep stale entries on every write rather than running a background
thread.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Dict, Optional, Tuple

from ._user import ClerkUser

logger = logging.getLogger(__name__)


_TTL_SECONDS = 24 * 3600
_MAX_ENTRIES = 4096

# renderer_id -> (last_touch_monotonic, user_or_none)
_REGISTRY: Dict[str, Tuple[float, Optional[ClerkUser]]] = {}

# Guards every mutation of — and iteration over — ``_REGISTRY``.
#
# The registry is written from the **main uvicorn loop** (the
# ``websocket_message`` hook calls :func:`attach`) AND read + TTL-touched from
# Dash's **callback worker threads** (``current_user()`` -> :func:`lookup`
# inside a WS-served callback body, which runs in the thread pool). Those are
# genuinely concurrent: the GIL makes each individual ``dict[k] = v`` /
# ``dict.pop(k)`` atomic, but it does NOT make a multi-item *iteration* atomic.
# So without this lock, :func:`attach`'s over-cap eviction sweep can iterate
# ``_REGISTRY`` while a worker thread's :func:`lookup` writes a touched TTL —
# raising ``RuntimeError: dictionary changed size during iteration`` under
# load. The lock is held only for O(1) dict ops (plus an O(n log n) sort on the
# rare over-cap sweep), so contention is negligible at any realistic WS scale.
_LOCK = threading.Lock()


def _evict_stale_locked() -> None:
    """Drop expired entries; if still over the cap, drop the oldest 25%.

    MUST be called with :data:`_LOCK` already held (the trailing ``_locked``
    is the contract). Iterates over a ``list()`` snapshot of the items so a
    concurrent mutation can never raise mid-sweep even if the locking
    invariant is ever violated.
    """
    now = time.monotonic()
    cutoff = now - _TTL_SECONDS
    stale = [k for k, (t, _) in list(_REGISTRY.items()) if t < cutoff]
    for k in stale:
        _REGISTRY.pop(k, None)

    if len(_REGISTRY) > _MAX_ENTRIES:
        # Drop the oldest 25% by last_touch.
        ordered = sorted(_REGISTRY.items(), key=lambda kv: kv[1][0])
        for k, _ in ordered[: max(1, _MAX_ENTRIES // 4)]:
            _REGISTRY.pop(k, None)


def attach(renderer_id: Optional[str], user: Optional[ClerkUser]) -> None:
    """Bind ``user`` to ``renderer_id`` for the lifetime of the WS connection.

    Called from the ``websocket_message`` hook in the asyncio task, before
    each callback dispatch. Idempotent — calling repeatedly with the same
    pair is cheap.
    """
    if not renderer_id:
        return
    with _LOCK:
        _REGISTRY[renderer_id] = (time.monotonic(), user)
        if len(_REGISTRY) > _MAX_ENTRIES:
            _evict_stale_locked()


def lookup(renderer_id: Optional[str]) -> Optional[ClerkUser]:
    """Return the user bound to ``renderer_id``, refreshing its TTL on read."""
    if not renderer_id:
        return None
    with _LOCK:
        entry = _REGISTRY.get(renderer_id)
        if entry is None:
            return None
        _, user = entry
        # Touch on read so an active long-lived WS doesn't expire mid-session.
        _REGISTRY[renderer_id] = (time.monotonic(), user)
        return user


def contains(renderer_id: Optional[str]) -> bool:
    """True when ``renderer_id`` has a binding — even an anonymous one.

    Distinct from :func:`lookup`, which returns ``None`` both for "absent"
    and for "bound to anonymous"; the message hook uses this to log only
    the FIRST bind of a renderer, not every refresh.
    """
    if not renderer_id:
        return False
    with _LOCK:
        return renderer_id in _REGISTRY


def detach(renderer_id: Optional[str]) -> None:
    """Drop the binding (call from a disconnect hook if available)."""
    if renderer_id:
        with _LOCK:
            _REGISTRY.pop(renderer_id, None)


def _reset_for_tests() -> None:
    """Clear the registry. Test-only — not part of the public API."""
    with _LOCK:
        _REGISTRY.clear()


def _ws_callback_from_context(ctx) -> Optional[object]:
    """Return the active WS callback object across Dash 4.2 version skew.

    The accessor was renamed mid-4.2: rc1/rc2 exposed a ``get_websocket()``
    **method**, rc3 and 4.2.0 final expose a ``websocket`` **property** (both
    return the concrete ``DashWebsocketCallback`` carrying ``_renderer_id``).
    We try the property first (current), then the legacy method, so the
    registry resolves on every 4.2.x — instead of being silently inert on an
    older pin, which is exactly how ``current_user()`` returned ``None`` in
    every WS callback for apps still on rc1.

    Accessing ``ctx.websocket`` can raise (the property is ``@has_context``
    guarded and raises ``RuntimeError`` when WS callbacks are requested on a
    backend without WS capability), so every access is defensively wrapped.
    """
    # rc3 / 4.2.0 final: the ``websocket`` property.
    try:
        ws = getattr(ctx, "websocket", None)
    except Exception:
        ws = None
    if ws is not None:
        return ws

    # rc1 / rc2: the legacy ``get_websocket()`` method.
    getter = getattr(ctx, "get_websocket", None)
    if callable(getter):
        try:
            ws = getter()
        except Exception:
            ws = None
        if ws is not None:
            return ws
    return None


def renderer_id_from_callback_context() -> Optional[str]:
    """Best-effort read of the active WS callback's renderer_id.

    Returns ``None`` when called outside a WS callback (e.g. inside a
    plain HTTP callback or at import time). Wraps the import + attribute
    walk so callers don't have to deal with Dash version skew.
    """
    try:
        from dash import callback_context  # type: ignore
    except Exception:
        return None
    ws = _ws_callback_from_context(callback_context)
    if ws is None:
        return None
    rid = getattr(ws, "_renderer_id", None) or getattr(ws, "renderer_id", None)
    if isinstance(rid, str) and rid:
        return rid
    return None
