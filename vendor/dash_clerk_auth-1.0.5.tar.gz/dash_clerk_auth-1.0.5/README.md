<div align="center">

# dash-clerk-auth

**Drop-in [Clerk](https://clerk.com) authentication for Plotly Dash — Flask, FastAPI and Quart, HTTP and WebSocket, one function call.**

[![PyPI version](https://badge.fury.io/py/dash-clerk-auth.svg)](https://pypi.org/project/dash-clerk-auth/)
[![Python](https://img.shields.io/pypi/pyversions/dash-clerk-auth.svg)](https://pypi.org/project/dash-clerk-auth/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![Tests](https://img.shields.io/badge/tests-136%20passing-brightgreen.svg)](tests/)

</div>

## Overview

Dash has no built-in authentication, and wiring a modern auth provider into it
by hand is harder than it looks: the sign-in UI must be injected into the Dash
index, every callback needs a server-side identity check, and on Dash 4.2 an
entire class of callbacks is delivered over a WebSocket through a thread pool
that no middleware, cookie, or ContextVar reaches.

`dash-clerk-auth` closes that gap. Two calls — `register_clerk_auth(...)` and
`configure_app(app)` — give you Clerk's hosted sign-in/sign-up flow, a signed
server-side identity cookie, fail-closed layout gating, and a `current_user()`
that returns the same verified identity on Flask and FastAPI, over HTTP and
WebSocket, in sync and async callbacks.

## Features

- 🔐 **One-call setup** — the sign-in UI, the `clerk-auth-store` Store, and the
  auth routes wire themselves up via Dash hooks.
- 🚀 **Flask, FastAPI and Quart** — `backend="auto"` detects the backend from
  `app.server` and installs the right middleware. Dash 3.x (Flask) and Dash 4.x
  (WSGI or ASGI) are both supported.
- 🍪 **Signed identity cookie** — the first request after sign-in pays one
  Clerk JWKS roundtrip and mints a signed `__dca_identity` cookie; every
  subsequent request verifies it locally in microseconds.
- 🛰️ **Dash 4.2+ WebSocket auth** — the ASGI middleware handles the WS
  handshake and a per-renderer identity registry bridges Dash's thread-pool
  callback dispatch, so `current_user()` works inside WS-served callbacks.
  Registered automatically since v0.9.
- 🛡️ **Server-side layout gating** — `@require_auth_layout`,
  `@require_role_layout`, `@require_plan_layout`, `@require_feature_layout`
  fail closed by default and commit to one branch *before* a heavy layout
  builds.
- 📧 **Enriched identities** — Clerk session JWTs carry no email claim by
  default; verified users are enriched via the users API (cached, once per
  user per process) so `user.email` is populated everywhere.
- 💰 **Clerk Billing** — `enable_billing=True` projects `plan` and `features`
  onto the user so pages and callbacks can gate on subscription state.
- 🌐 **Multi-domain (satellite) support** — first-class
  `is_satellite` / `satellite_domain` configuration for sharing one Clerk
  session across several domains.
- 🧰 **Async and sync Clerk API wrappers** — TTL-cached, single-flight
  `averify_request` / `aget_user_by_id` / `alist_users_cached` for the event
  loop, plus loop-free `*_sync` twins that are safe inside Dash 4.2 WS
  callback bodies and worker threads.

## Installation

```bash
# Flask backend (Dash 3 or 4 WSGI):
pip install dash-clerk-auth

# Dash 4 ASGI (FastAPI) — required for WebSocket auth:
pip install 'dash-clerk-auth[fastapi]' 'dash[fastapi]>=4.2'
```

### Compatibility

| Dependency | Declared | Verified against |
|---|---|---|
| Python | `>=3.10` | 3.12 |
| Dash | `>=3.0.3` | 3.0.x, 4.1, 4.2.0, 4.4.1 |
| `clerk-backend-api` | `>=5.0.0,<8` | 5.0.6, 5.0.7, 7.0.0 |
| `dash-mantine-components` | `>=2.3.0` | 2.3, 2.4, 2.6, 2.7 |

You will also need a [Clerk](https://clerk.com) account and its API keys
(free tier is fine).

## Quick start — Flask (Dash 3.x or 4.x WSGI)

```python
import os
from dash import Dash
import dash_mantine_components as dmc
from dash_clerk_auth import register_clerk_auth, configure_app

register_clerk_auth(
    clerk_secret_key=os.environ["CLERK_SECRET_KEY"],
    clerk_publishable_key=os.environ["CLERK_PUBLISHABLE_KEY"],
    clerk_sign_in_url=os.environ["CLERK_SIGN_IN_URL"],
    session_secret=os.environ["SESSION_SECRET"],   # signs the identity cookie
)

app = Dash(__name__, external_stylesheets=[dmc.styles.ALL])
configure_app(app)

app.layout = dmc.MantineProvider(dmc.Container("Hello, Clerk!", py="xl"))

if __name__ == "__main__":
    app.run(debug=True)
```

## Quick start — FastAPI (Dash 4.2+ with WebSocket callbacks)

```python
import os
from dash import Dash
import dash_mantine_components as dmc
from dash_clerk_auth import register_clerk_auth, configure_app

register_clerk_auth(
    clerk_secret_key=os.environ["CLERK_SECRET_KEY"],
    clerk_publishable_key=os.environ["CLERK_PUBLISHABLE_KEY"],
    clerk_sign_in_url=os.environ["CLERK_SIGN_IN_URL"],
    session_secret=os.environ["SESSION_SECRET"],
    backend="auto",            # detects FastAPI from app.server
)

app = Dash(__name__, backend="fastapi", external_stylesheets=[dmc.styles.ALL])
configure_app(app)             # WebSocket auth hooks register automatically

server = app.server            # run with: uvicorn app:server --port 8050
```

`app.server` is now a FastAPI instance with the Clerk middleware on HTTP and
WebSocket scope, the signed-cookie session middleware, and the
`/api/auth/{session,signout}` routes mounted. To customise the WS behaviour
(e.g. `on_anonymous="close"`), call `register_websocket_auth(...)` yourself
**before** `configure_app` — it is idempotent and the first registration wins.
Opt out entirely with `register_clerk_auth(..., websocket_auth=False)`.

### Choosing the WebSocket transport (Dash 4.2+)

Prefer per-callback `@callback(websocket=True)` over the global
`Dash(websocket_callbacks=True)` flag. With the per-callback opt-in, ordinary
callbacks ride HTTP — where cookies and middleware exist — and only the
callbacks that need the socket (streaming, `set_props`, persistent callbacks)
use it:

```python
app = Dash(__name__, backend="fastapi")   # global WS flag OFF

@callback(Output("feed", "children"), Input("tick", "n_intervals"),
          websocket=True)                 # only THIS callback rides the socket
async def stream_feed(_):
    ...
```

With the global flag on, **every** callback — including the pages router — is
delivered over the WebSocket and executes in a thread pool, so server-side
identity depends entirely on the WS auth hooks. They are registered
automatically since v0.9, but the narrower opt-in keeps most of your app on
the well-understood HTTP path.

## Reading identity in your code

### From a callback (any backend, HTTP or WS)

```python
from dash import Input, Output, callback
from dash_clerk_auth import current_user

@callback(
    Output("greeting", "children"),
    Input("clerk-auth-store", "data"),   # fires on session change
)
def greet(_auth_data):
    user = current_user()                # backend- and transport-neutral
    if user is None:
        return "Sign in to continue."
    return f"Welcome, {user.first_name or user.email}!"
```

### Gating a Dash page server-side

```python
import dash
from dash_clerk_auth import require_role_layout

@require_role_layout("admin")            # fail-closed by default
def layout(**_kwargs):
    return _build_heavy_admin_dashboard()  # never builds for anonymous visitors

dash.register_page(__name__, path="/admin", layout=layout)
```

The `@require_*_layout` family commits to one branch — protected layout or
placeholder — *before* any callback fires, so an expensive admin layout is
never rendered for an anonymous visitor or a bot crawl.

> **Always accept `**kwargs` in callable page layouts.** Dash Pages forwards
> query-string parameters to callable layouts as keyword arguments, and
> Clerk's sign-in flow redirects back with `?__clerk_handshake=...` — a bare
> `def layout():` raises `TypeError` (a 500) on exactly that redirect.

### Gating on a Clerk Billing plan or feature flag

```python
from dash_clerk_auth import require_plan_layout, require_feature_layout

@require_plan_layout(["pro", "enterprise"])
def layout(**_kwargs):
    return _build_pro_dashboard()

@require_feature_layout("advanced_export")
def layout(**_kwargs):
    return _build_export_panel()
```

Pair with `register_clerk_auth(..., enable_billing=True)` so the JWT's plan
and feature claims are projected onto the user.

### Calling the Clerk API from callbacks

```python
# Async — on the main event loop (FastAPI HTTP callbacks):
from dash_clerk_auth import alist_users_cached
users = await alist_users_cached()          # 60s TTL, single-flight

# Sync — safe in Dash 4.2 WS callback bodies and worker threads:
from dash_clerk_auth import get_user_by_id_sync, set_user_role_sync
user = get_user_by_id_sync("user_2abc...")
set_user_role_sync("user_2abc...", "admin")
```

Dash 4.2 runs each WS callback via `asyncio.run()` in a thread pool, so a
process-cached async client raises `RuntimeError: Event loop is closed` there.
The `*_sync` helpers exist for exactly that context; keep the `a*` helpers on
the main event loop.

## Configuration reference

```python
register_clerk_auth(
    # --- required ---
    clerk_secret_key="sk_test_...",          # from the Clerk dashboard
    clerk_publishable_key="pk_test_...",
    clerk_sign_in_url="https://your-app.clerk.accounts.dev/sign-in",

    # --- session + identity cookie ---
    session_secret="long-random-string",     # signs the session AND __dca_identity
    session_lifetime_days=7,                 # cookie Max-Age

    # --- backend ---
    backend="auto",                          # "auto" | "flask" | "fastapi" | "quart"
    on_unverified="forbidden",               # layout-decorator default: forbidden | allow | passthrough
    verify_timeout=5.0,
    authorized_parties=None,                 # optional Clerk azp whitelist
    websocket_auth=True,                     # auto-register Dash 4.2 WS auth hooks (ASGI)

    # --- billing ---
    enable_billing=False,                    # populates user.plan + user.features

    # --- ergonomics ---
    debug=False,
    show_debug_panel=None,
    headless=False,                          # skip the injected avatar UI
    enable_proxy_fix=True,                   # Flask only

    # --- multi-domain (satellites) ---
    is_satellite=False,
    satellite_domain=None,                   # e.g. "docs.example.com"
    sign_up_url=None,                        # primary's sign-up page
    clerk_frontend_api=None,                 # https://<app>.clerk.accounts.dev
    allowed_redirect_origins=None,           # on the primary: satellite origins
)

# Registered automatically by configure_app since v0.9 (ASGI backends).
# Call it yourself BEFORE configure_app only to customise — first one wins:
register_websocket_auth(
    on_anonymous="allow",                    # "allow" (default) | "close" (fail-closed)
    close_code=4401,
    close_reason="unauthenticated",
)
```

> **`SESSION_SECRET` must be a fixed value** — identical across replicas and
> across deploys. It signs the `__dca_identity` cookie; a per-deploy generated
> secret invalidates every signed identity on each release. The symptom is
> repeated slow-path Clerk verifies right after deploying.

## Multi-domain: sharing one session across satellites

One Clerk application can serve several domains: a **primary** that hosts
sign-in, and **satellites** that share its session. Configure each satellite
with:

```python
register_clerk_auth(
    clerk_secret_key=os.environ["CLERK_SECRET_KEY"],          # same app as primary
    clerk_publishable_key=os.environ["CLERK_PUBLISHABLE_KEY"],
    clerk_frontend_api=os.environ["CLERK_FRONTEND_API"],      # <app>.clerk.accounts.dev
    is_satellite=True,
    satellite_domain="docs.example.com",                      # host only, no protocol
    sign_in_url="https://example.com/sign-in",                # the PRIMARY's page
    sign_up_url="https://example.com/sign-up",
    session_secret=os.environ["SESSION_SECRET"],
)
```

and list each satellite origin in `allowed_redirect_origins=[...]` on the
primary. Since v0.9.1 the generated ClerkJS script tag carries
`data-clerk-domain` in satellite mode — required because ClerkJS v5
auto-instantiates from the script tag's data attributes and ignores a domain
passed only to `Clerk.load()`.

See `examples/pages/multi_domain.py` for a complete worked example of a
multi-domain galaxy.

## How identity resolution works

Every authenticated request takes one of two paths:

1. **Fast path** — the signed `__dca_identity` cookie is present and valid
   (HMAC verify, microseconds, no I/O). Almost all requests hit this.
2. **Slow path** — no valid cookie → verify with Clerk
   (`authenticate_request_async`, JWKS roundtrip) and mint a fresh cookie on
   the response. This happens on the first request after sign-in, then once
   per `session_lifetime_days`.

The cookie is signed with `itsdangerous.URLSafeTimedSerializer(session_secret)`,
is `HttpOnly` + `SameSite=Lax` (with `Secure` behind a TLS-terminating proxy),
and is bounded by `session_lifetime_days` rather than the JWT's `exp` — Clerk
dev JWTs rotate every ~60 seconds; the cookie's job is to cache the *identity*
across many JWT refreshes.

For Dash 4.2 WebSocket-served callbacks the package additionally runs the
middleware on the WS handshake and bridges the thread-pool callback dispatch
through a `renderer_id → user` registry, because `concurrent.futures` does not
propagate ContextVars into worker threads. `current_user()` reads, in order:
ContextVar → WS renderer registry → Flask `g` → Flask `session` → `None`.

## The auth store

A hidden `dcc.Store(id="clerk-auth-store")` is injected and pre-populated
server-side at layout build time, then kept in sync client-side on every Clerk
session change:

```python
{
    "user_id": "user_2abc123...",
    "session_id": "sess_2def456...",
    "email": "user@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "image_url": "https://img.clerk.com/...",
    "role": "admin",                    # when present in JWT public_metadata
    "plan": "pro",                      # when enable_billing=True
    "features": ["advanced_export"],    # when enable_billing=True
}
```

## Examples

The repo's `examples/` folder ships two runnable apps and a page per feature:

- `examples/app.py` — Flask backend (Dash 3 / 4 WSGI)
- `examples/app_fastapi.py` — FastAPI backend with WebSocket callbacks
- `examples/pages/` — quickstart, auth store, layout gating, billing,
  multi-domain, debug panel, and more

There is also a full e-commerce template (9 pages, dynamic pricing, complete
membership flow) built on this package with Stripe via Clerk Billing:
[shop.geomapindex.com](https://shop.geomapindex.com/catalogue/dash-clerk-auth-stripe-billing_9/),
and a video walkthrough: [Clerk + Stripe + Dash demo](https://youtu.be/SOQhRhQQqbA).

## Troubleshooting

**`current_user()` returns `None` inside a Dash 4.2 WS callback**
- Use `dash-clerk-auth >= 0.9` — the WS auth hooks register automatically on
  ASGI backends. Assert with `dash_clerk_auth.ws_auth_registered()` (e.g. from
  a health endpoint). On 0.7–0.8, call `register_websocket_auth()` explicitly.

**`user.email` is `None` for a signed-in user** *(fixed in v0.9)*
- Clerk session JWTs carry no email claim by default. Since v0.9 verified
  identities are enriched via Clerk's users API before caching or minting the
  identity cookie. Alternative that skips the API call: customise the
  instance's session token in the Clerk dashboard to include
  `{"email": "{{user.primary_email_address}}"}`.

**Satellite domain throws `ClerkJS: Missing domain and proxyUrl`** *(fixed in v0.9.1)*
- With the script-tag installation, ClerkJS v5 reads the domain from the
  tag's data attributes, not from `Clerk.load()`. v0.9.1 emits
  `data-clerk-domain` on the script tag when `is_satellite=True`. The
  symptom on older versions: server-side auth works but the user button
  never mounts (dead avatar).

**`__dca_identity` cookie isn't being set**
- Check the logs for `slow-path Clerk verify rejected ...` — the reject reason
  is logged, including the JWT `kid` on KID mismatch.
- Most common cause: signed into multiple Clerk dev apps on `localhost`. The
  package strips other apps' suffixed cookies (v0.7); clear cookies and
  re-sign-in if it persists.
- Also check that `CLERK_SECRET_KEY` and `CLERK_PUBLISHABLE_KEY` belong to the
  same Clerk application.

**Page locks me out, then a refresh fixes it**
- The v0.6-era WS-bypasses-middleware bug, fixed in v0.7. Upgrade.

**User stays logged in after logout**
- `/api/auth/signout` clears the identity cookie and session. The built-in
  dropdown calls it; custom UIs must POST `/api/auth/signout` themselves.

**`RuntimeError: dictionary changed size during iteration` on WS disconnect**
- A known Dash 4.2.0 upstream bug in the FastAPI backend's disconnect cleanup,
  not a dash-clerk-auth issue. Harmless teardown noise; fixed upstream.

### Debug mode

```python
register_clerk_auth(..., debug=True, show_debug_panel=True)

import logging
logging.basicConfig(level=logging.INFO)
logging.getLogger("dash_clerk_auth").setLevel(logging.DEBUG)
```

## Development

```bash
pip install -e '.[dev]'
pytest tests/ -q          # 136 tests
python -m build           # sdist + wheel
```

Contributions are welcome — fork, create a feature branch, add tests for the
change, and open a pull request. Please update `CHANGELOG.md` in the same
commit as the change.

## Support

- 🐛 **Issues** — [github.com/pip-install-python/dash-clerk-auth/issues](https://github.com/pip-install-python/dash-clerk-auth/issues)
- 💬 **Discord** — [join the server](https://discord.gg/e5s5uHWUHH)
- 📋 **Dash community forum** — [community.plotly.com](https://community.plotly.com/)

## More from Pip Install Python LLC

| Project | What it is |
|---|---|
| 📚 **[pip-install-python on GitHub](https://github.com/pip-install-python)** | Open-source Dash component libraries and their documentation |
| 🗺️ **[dash-leaflet2](https://pypi.org/project/dash-leaflet2/)** | Leaflet 2-native mapping components for Dash 4 |
| 🗺️ **[Geo Map Index](https://dash.geomapindex.com/)** | Geospatial tooling for Dash |
| 🛒 **[shop.geomapindex.com](https://shop.geomapindex.com/catalogue/)** | Dash app templates and e-commerce examples |

## License

MIT — see [LICENSE](LICENSE). Built by
**[Pip Install Python LLC](https://github.com/pip-install-python)**.

## Acknowledgments

- [Plotly Dash](https://dash.plotly.com/) — the framework
- [Clerk](https://clerk.com/) — the authentication platform
- [Dash Mantine Components](https://dash-mantine-components.com/) — the UI library
