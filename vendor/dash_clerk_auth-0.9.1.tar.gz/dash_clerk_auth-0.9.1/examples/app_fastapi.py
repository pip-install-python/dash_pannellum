"""dash-clerk-auth — FastAPI/ASGI demo (Dash 4.x ``backend="fastapi"``).

Mirror of ``examples/app.py`` but on the ASGI stack. Demonstrates:

- ``register_clerk_auth(backend="auto")`` autodetecting FastAPI from
  ``app.server`` and installing the ASGI middleware.
- ``@require_role_layout("admin")`` returning a forbidden placeholder
  for anonymous visitors WITHOUT building the heavy admin layout —
  the fix for the production hang documented in the v0.6 spec.
- ``async def`` callbacks awaiting ``alist_users_cached()`` instead of
  blocking the event loop on a sync Clerk SDK call.

Environment (.env or exported):
    CLERK_SECRET_KEY=sk_test_...
    CLERK_PUBLISHABLE_KEY=pk_test_...
    CLERK_SIGN_IN_URL=https://your-app.clerk.accounts.dev/sign-in
    SESSION_SECRET=<random>
    DEBUG=True

Run:
    pip install 'dash-clerk-auth[fastapi]'
    uvicorn examples.app_fastapi:server --host 0.0.0.0 --port 8050 --reload

This module exposes ``server`` (the FastAPI ASGI app) so uvicorn can find it.
"""

from __future__ import annotations

import logging
import os
import sys
import time

import dash
import dash_mantine_components as dmc
from dash import Dash, dcc, html, page_container, callback, Input, Output, State

try:
    from dotenv import load_dotenv, find_dotenv
    load_dotenv(find_dotenv(), override=True)
except ImportError:
    pass

# v0.7 — surface the dash_clerk_auth INFO logs (slow-path verifies, cookie
# minting, anonymous decisions) so it's obvious whether the identity
# cookie path is firing. Without this, Python's default logger threshold
# is WARNING and the diagnostic messages get swallowed.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-7s %(name)s · %(message)s",
)
logging.getLogger("dash_clerk_auth").setLevel(logging.DEBUG)

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)


# Dash 4.2+ exposes the `backend="fastapi"` constructor kwarg. On older
# Dash, this demo can't run — print actionable guidance instead of
# crashing with a generic TypeError.
import inspect as _inspect
_DASH_INIT_SIG = _inspect.signature(Dash.__init__)
if "backend" not in _DASH_INIT_SIG.parameters:
    raise SystemExit(
        f"This demo requires Dash >= 4.2.0rc1 (your version exposes no "
        f"`backend=` constructor arg). Upgrade with:\n"
        f"    pip install --upgrade --pre dash\n"
        f"For a Flask-mode demo on older Dash, see examples/app.py instead."
    )


# ---------------------------------------------------------------------------
# Clerk configuration — same call as the Flask app, but backend="auto"
# detects FastAPI from app.server and wires the ASGI middleware.
# ---------------------------------------------------------------------------
CLERK_SECRET_KEY = os.getenv("CLERK_SECRET_KEY")
CLERK_PUBLISHABLE_KEY = os.getenv("CLERK_PUBLISHABLE_KEY")
CLERK_SIGN_IN_URL = os.getenv("CLERK_SIGN_IN_URL")
SESSION_SECRET = os.getenv("SESSION_SECRET", "demo-secret-change-me")

CLERK_CONFIGURED = all([CLERK_SECRET_KEY, CLERK_PUBLISHABLE_KEY, CLERK_SIGN_IN_URL])

if CLERK_CONFIGURED:
    from dash_clerk_auth import register_clerk_auth

    register_clerk_auth(
        clerk_secret_key=CLERK_SECRET_KEY,
        clerk_publishable_key=CLERK_PUBLISHABLE_KEY,
        clerk_sign_in_url=CLERK_SIGN_IN_URL,
        session_secret=SESSION_SECRET,
        enable_billing=False,
        headless=True,
        backend="auto",                    # ← v0.6 — autodetects "fastapi"
        on_unverified="forbidden",         # ← fail closed (v0.6 default)
        verify_timeout=5.0,
    )


# ---------------------------------------------------------------------------
# Dash app on the FastAPI backend
# ---------------------------------------------------------------------------
app = Dash(
    __name__,
    backend="fastapi",                     # ← Dash 4 ASGI mode
    use_pages=True,
    pages_folder=os.path.join(_THIS_DIR, "pages"),
    external_stylesheets=[dmc.styles.ALL],
    suppress_callback_exceptions=True,
)
server = app.server                        # ← FastAPI instance — uvicorn target
app.title = "dash-clerk-auth — FastAPI demo"

if CLERK_CONFIGURED:
    from dash_clerk_auth import configure_app, create_clerk_menu

    configure_app(app)
    _menu_slot = create_clerk_menu()
else:
    _menu_slot = dmc.Badge("Clerk not configured", color="gray", variant="light")


# v0.7 — surface route-handler exceptions so the cold-start 500 leaves a
# traceback in the terminal. Dash's FastAPI backend silently converts
# unhandled exceptions to 500 with no log line; this ASGI middleware
# wraps the inner app and logs the traceback BEFORE re-raising.
class _ExceptionSurfacer:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        try:
            await self.app(scope, receive, send)
        except Exception:
            logging.getLogger("examples.app_fastapi").exception(
                "Unhandled exception in %s %s",
                scope.get("method", "?"),
                scope.get("path", "?"),
            )
            raise


server.add_middleware(_ExceptionSurfacer)


# ---------------------------------------------------------------------------
# An admin-only page registered inline via dash.register_page so the demo
# is self-contained. In a real app this would live under pages/.
# ---------------------------------------------------------------------------
from dash_clerk_auth import (
    require_role_layout,
    callback_user,
    alist_users_cached,
    current_user,
    is_authenticated,
)


def _heavy_admin_content():
    """Stand-in for the kind of layout that hangs the worker in production
    — pretend it does heavy server-side work to build a table."""
    time.sleep(0.2)  # simulated render cost
    return dmc.Stack(
        [
            dmc.Title("Admin · users", order=2),
            dmc.Text(
                "This layout is expensive to build. Anonymous visitors must "
                "NEVER pay this cost — that's what require_role_layout "
                "guarantees, fail-closed by default.",
                c="dimmed",
            ),
            dmc.Group(
                [
                    dmc.Button("Refresh", id="admin-refresh-btn", variant="light"),
                    dmc.Text(id="admin-refresh-status", c="dimmed", size="sm"),
                ],
            ),
            html.Div(id="admin-users-table"),
        ],
        gap="md",
    )


@require_role_layout("admin")
def admin_layout():
    return _heavy_admin_content()


# Register as a page so /admin works under use_pages=True.
dash.register_page(
    __name__ + ".admin",
    path="/admin",
    name="Admin (gated)",
    layout=admin_layout,
)


@callback(
    Output("admin-users-table", "children"),
    Output("admin-refresh-status", "children"),
    Input("admin-refresh-btn", "n_clicks"),
    State("admin-refresh-btn", "n_clicks"),
    prevent_initial_call=False,
)
async def _load_admin_users(n_clicks, _state):
    """Async callback — does NOT block the FastAPI event loop.

    The cache means initial render and tab navigation don't roundtrip
    Clerk; only the explicit Refresh click busts the cache.
    """
    user = callback_user()
    if user is None or not user.has_role("admin"):
        return dmc.Alert("Not authorised", color="red"), ""

    force = bool(n_clicks and n_clicks > 0)
    started = time.monotonic()
    users = await alist_users_cached(force=force)
    elapsed = (time.monotonic() - started) * 1000

    rows = [
        dmc.Group(
            [
                dmc.Text(u.get("email") or u.get("id") or "(no email)", fw=500),
                dmc.Text(u.get("first_name") or "", c="dimmed", size="sm"),
            ],
            gap="md",
        )
        for u in users[:25]
    ]
    return (
        dmc.Stack(rows or [dmc.Text("No users", c="dimmed")]),
        f"Loaded {len(users)} users in {elapsed:.0f} ms (cached={not force})",
    )


# ---------------------------------------------------------------------------
# Top-level layout
# ---------------------------------------------------------------------------
def _home():
    user = current_user()
    if user is None:
        identity = dmc.Alert(
            "Anonymous visitor — sign in via the avatar above to see the admin page.",
            color="blue",
            variant="light",
        )
    else:
        identity = dmc.Alert(
            f"Signed in as {user.email or user.user_id} (role={user.role or 'none'})",
            color="green",
            variant="light",
        )
    return dmc.Stack(
        [
            dmc.Title("dash-clerk-auth · FastAPI demo", order=1),
            identity,
            dmc.Text(
                "v0.7.0 adds the signed __dca_identity cookie + Dash 4.2 "
                "WebSocket-aware ASGI middleware on top of the v0.6 layout "
                "decorators and async Clerk client.",
                c="dimmed",
            ),
            dmc.NavLink(
                label="Go to /admin (gated by require_role_layout)",
                href="/admin",
                leftSection=html.Span("→"),
            ),
        ],
        gap="md",
    )


dash.register_page(__name__ + ".home", path="/", name="Home", layout=_home)


app.layout = dmc.MantineProvider(
    [
        dmc.AppShell(
            [
                dmc.AppShellHeader(
                    dmc.Group(
                        [
                            # Title doubles as the home button — clicking it
                            # routes back to / via Dash's pages router.
                            dcc.Link(
                                dmc.Title(
                                    "dash-clerk-auth · FastAPI demo",
                                    order=4,
                                    style={"cursor": "pointer"},
                                ),
                                href="/",
                                style={"textDecoration": "none", "color": "inherit"},
                                refresh=False,
                            ),
                            _menu_slot,
                        ],
                        justify="space-between",
                        h="100%",
                        px="md",
                    )
                ),
                dmc.AppShellMain(dmc.Container(page_container, size="lg", py="lg")),
            ],
            header={"height": 60},
            padding="md",
        ),
    ],
    id="mantine-provider",
    defaultColorScheme="light",
)


if __name__ == "__main__":
    # For convenience — but `uvicorn examples.app_fastapi:server` is preferred
    # in production / for hot-reload.
    #
    # IMPORTANT: pass ``reload=False`` here. With ``reload=True``, uvicorn
    # spawns a watcher subprocess that re-imports this file as the module
    # ``examples.app_fastapi`` while the original ``__main__`` import is
    # still resident. Module-level code runs twice in the same process,
    # which double-registers ``register_clerk_auth`` (see the
    # "Clerk auth already initialized, skipping re-initialization" warning)
    # and races a doomed Dash app against the real one — that's what
    # produces the one-time 500 on the cold hit.
    #
    # If you want hot-reload, run uvicorn directly so only the spawned
    # worker imports this file:
    #   uvicorn examples.app_fastapi:server --port 8050 --reload
    import uvicorn

    print("=" * 64)
    print("  dash-clerk-auth FastAPI demo")
    print(f"  Clerk: {'ACTIVE' if CLERK_CONFIGURED else 'NOT CONFIGURED'}")
    print("  Hot-reload? Run: uvicorn examples.app_fastapi:server --port 8050 --reload")
    print("=" * 64)
    uvicorn.run("examples.app_fastapi:server", host=".0.0.0", port=8050, reload=False)
