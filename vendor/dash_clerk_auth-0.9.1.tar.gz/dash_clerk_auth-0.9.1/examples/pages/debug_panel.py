"""
Debug panel — the in-browser auth inspector.

A fixed-position glass panel the hook injects in the bottom-right corner when
show_debug_panel=True (or debug=True). Shows user_id, email, name, session_id
(plus plan/features when billing is enabled).
"""

import dash
import dash_mantine_components as dmc
from dash import html
from dash_iconify import DashIconify

dash.register_page(__name__, path="/debug-panel", name="Debug panel", order=8)

ENABLE = """from dash_clerk_auth import register_clerk_auth

register_clerk_auth(
    # ... keys ...
    debug=True,              # enables logging + panel (default: False)
    show_debug_panel=True,   # force panel on regardless of debug
)
"""

DISABLE = """register_clerk_auth(
    # ... keys ...
    debug=True,              # logging stays on
    show_debug_panel=False,  # hide the panel (e.g. staging builds)
)
"""


layout = dmc.Stack(
    [
        dmc.Title("Debug panel", order=1),
        dmc.Text(
            "A fixed-position inspector in the bottom-right corner. It updates live "
            "as the Clerk session changes, so you can watch sign-in, sign-out, and "
            "user-switch events without hitting the dev console.",
            c="dimmed",
        ),
        dmc.Paper(
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="tabler:bug", width=20),
                            dmc.Text("What it shows", fw=600),
                        ],
                        gap="sm",
                    ),
                    dmc.List(
                        [
                            dmc.ListItem(dmc.Group([dmc.Code("User ID"), dmc.Text(" — the Clerk user identifier, e.g. user_2...", size="sm")], gap=4)),
                            dmc.ListItem(dmc.Group([dmc.Code("Email"), dmc.Text(" — primary email address on record.", size="sm")], gap=4)),
                            dmc.ListItem(dmc.Group([dmc.Code("Name"), dmc.Text(" — first + last name.", size="sm")], gap=4)),
                            dmc.ListItem(dmc.Group([dmc.Code("Session ID"), dmc.Text(" — the Clerk session token ID, useful for reproducing tickets.", size="sm")], gap=4)),
                            dmc.ListItem(dmc.Group([dmc.Code("Plan"), dmc.Text(" — only when billing is enabled.", size="sm")], gap=4)),
                        ],
                        size="sm",
                        spacing=4,
                    ),
                    dmc.Text(
                        "Each row has a subtle hover state and monospace type so values stay "
                        "readable when you're copy-pasting into a bug report.",
                        size="sm",
                        c="dimmed",
                    ),
                ],
                gap="sm",
            ),
            p="lg",
            radius="md",
            withBorder=True,
        ),
        dmc.Alert(
            dmc.Text(
                "If the debug panel is on right now (DEBUG=True or show_debug_panel=True), "
                "look in the bottom-right corner — the panel renders there via a fixed-"
                "position Div. Sign in with the avatar to watch the values change live.",
                size="sm",
            ),
            title="Look bottom-right",
            color="blue",
            icon=DashIconify(icon="tabler:arrow-down-right"),
        ),
        dmc.Title("Turning it on", order=3, mt="md"),
        dmc.CodeHighlight(code=ENABLE, language="python"),
        dmc.Title("Logs on, panel off", order=3, mt="md"),
        dmc.Text(
            "Sometimes you want the server logs but not the UI panel (e.g. in a shared "
            "staging build). Pass show_debug_panel=False explicitly — the panel is the only "
            "piece that gets suppressed.",
            size="sm",
        ),
        dmc.CodeHighlight(code=DISABLE, language="python"),
        dmc.Title("In production", order=3, mt="md"),
        dmc.Text(
            "Leave debug and show_debug_panel at their defaults (both False). The panel is "
            "purely a developer convenience — it exposes session IDs and emails, so keep it "
            "off for end users.",
            size="sm",
        ),
    ],
    gap="md",
)