"""
User info helpers — the non-decorator utility API.

These functions read the server-side Flask session (populated by the hook
during /api/auth/session). They're useful inside Flask routes or any code
that runs outside a Dash callback context.
"""

import json

import dash
import dash_mantine_components as dmc
from dash import Input, Output, State, callback, html
from dash_iconify import DashIconify

dash.register_page(__name__, path="/user-info", name="User info helpers", order=7)

HELPERS = [
    {
        "name": "get_current_user_id()",
        "returns": "str | None",
        "desc": "The Clerk user ID (`user_2...`) if a Flask session is present, else None.",
    },
    {
        "name": "get_user_info(user_id=None)",
        "returns": "dict | None",
        "desc": (
            "Full user profile: id, email, first_name, last_name, image_url, "
            "email_addresses (list). Passes through to the Clerk SDK on a "
            "session miss. Includes plan/features when billing is enabled."
        ),
    },
    {
        "name": "get_current_user_plan()",
        "returns": "str | None",
        "desc": "Plan slug ('free', 'pro', 'enterprise', ...) or None when billing is disabled.",
    },
    {
        "name": "get_current_user_features()",
        "returns": "list[str]",
        "desc": "Feature list from the JWT. Empty list when billing is disabled.",
    },
    {
        "name": "has_plan(plans)",
        "returns": "bool",
        "desc": (
            "Case-insensitive plan check. Accepts a single plan name or a list. "
            "Always returns True when billing is disabled — it's a soft gate, "
            "not a hard one."
        ),
    },
    {
        "name": "has_feature(name)",
        "returns": "bool",
        "desc": "Membership test against get_current_user_features().",
    },
]

EXAMPLE = '''from flask import jsonify
from dash_clerk_auth import (
    get_current_user_id,
    get_user_info,
    has_plan,
    has_feature,
)

@app.server.route("/api/me")
def me():
    uid = get_current_user_id()
    if not uid:
        return jsonify(error="not signed in"), 401
    return jsonify(
        user=get_user_info(),
        is_pro=has_plan(["pro", "enterprise"]),
        can_export=has_feature("charts_export"),
    )
'''


def _helper_row(helper):
    return dmc.TableTr(
        [
            dmc.TableTd(dmc.Code(helper["name"])),
            dmc.TableTd(dmc.Code(helper["returns"])),
            dmc.TableTd(dmc.Text(helper["desc"], size="sm")),
        ]
    )


layout = dmc.Stack(
    [
        dmc.Title("User info helpers", order=1),
        dmc.Text(
            "Six pure-Python functions that read the session synchronously. Use them "
            "in Flask routes, background tasks, and anywhere the Dash callback graph "
            "isn't a good fit.",
            c="dimmed",
        ),
        dmc.Paper(
            dmc.Table(
                [
                    dmc.TableThead(
                        dmc.TableTr([dmc.TableTh("Function"), dmc.TableTh("Returns"), dmc.TableTh("Description")])
                    ),
                    dmc.TableTbody([_helper_row(h) for h in HELPERS]),
                ],
                striped=True,
                withTableBorder=True,
            ),
            p="md",
            radius="md",
            withBorder=True,
        ),
        # Live demo — mirrors what the helpers return for the current user
        dmc.Paper(
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="tabler:user-circle", width=20),
                            dmc.Text("Live values", fw=600),
                            dmc.Badge("reads clerk-auth-store", color="blue", variant="light", size="xs"),
                        ],
                        gap="sm",
                    ),
                    dmc.Text(
                        "Signed-in user values — these mirror what the server-side "
                        "helpers would return for you right now.",
                        size="sm",
                        c="dimmed",
                    ),
                    dmc.CodeHighlight(
                        id="user-info-live",
                        code="Waiting for clerk-auth-store...",
                        language="python",
                    ),
                ],
                gap="sm",
            ),
            p="lg",
            radius="md",
            withBorder=True,
        ),
        dmc.Title("Example: a /api/me Flask route", order=3, mt="md"),
        dmc.CodeHighlight(code=EXAMPLE, language="python"),
    ],
    gap="md",
)


@callback(
    Output("user-info-live", "code"),
    Input("clerk-auth-store", "data"),
)
def _render_values(auth):
    auth = auth or {}
    if not auth.get("user_id"):
        return (
            "# Not signed in\n"
            "get_current_user_id()       -> None\n"
            "get_user_info()             -> None\n"
            "get_current_user_plan()     -> None  (billing disabled) or 'free'\n"
            "get_current_user_features() -> []\n"
            "has_plan('pro')             -> False\n"
            "has_feature('api_access')   -> False"
        )

    uid = auth.get("user_id")
    email = auth.get("email", "")
    first = auth.get("first_name", "")
    last = auth.get("last_name", "")
    plan = auth.get("plan")
    features = auth.get("features") or []

    return (
        f"get_current_user_id()       -> {uid!r}\n"
        f"get_user_info()             -> {{\n"
        f"    'id':         {uid!r},\n"
        f"    'email':      {email!r},\n"
        f"    'first_name': {first!r},\n"
        f"    'last_name':  {last!r},\n"
        f"    'plan':       {plan!r},\n"
        f"    'features':   {features!r},\n"
        f"}}\n"
        f"get_current_user_plan()     -> {plan!r}\n"
        f"get_current_user_features() -> {features!r}\n"
        f"has_plan('pro')             -> {plan == 'pro'}\n"
        f"has_feature('api_access')   -> {'api_access' in features}"
    )