"""
Changelog — rendered from the repo's CHANGELOG.md.
"""

import os
import dash
import dash_mantine_components as dmc
from dash import dcc, html

dash.register_page(__name__, path="/changelog", name="Changelog", order=99)

# CHANGELOG.md lives at the repo root (two levels up from examples/pages/).
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_CHANGELOG_PATH = os.path.join(_REPO_ROOT, "CHANGELOG.md")

try:
    with open(_CHANGELOG_PATH, encoding="utf-8") as _f:
        _markdown = _f.read()
except FileNotFoundError:
    _markdown = "*CHANGELOG.md not found.*"

layout = dmc.Stack(
    [
        dmc.Title("Changelog", order=1),
        dmc.Text(
            "All notable changes to dash-clerk-auth. Rendered live from CHANGELOG.md at "
            "the repo root.",
            c="dimmed",
        ),
        dmc.Paper(
            dcc.Markdown(
                _markdown,
                style={"fontSize": 14, "lineHeight": 1.7},
            ),
            p="xl",
            radius="md",
            withBorder=True,
        ),
    ],
    gap="md",
    style={"maxWidth": 820},
)