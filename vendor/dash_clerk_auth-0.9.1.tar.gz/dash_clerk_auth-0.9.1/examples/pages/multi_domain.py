"""
Multi-domain — running dash-clerk-auth across a satellite galaxy.

Modeled on the 2plot Galaxy architecture
(https://github.com/pip-install-python/2plot): a single Docker image boots
different domains based on ``DOMAIN_APP``, one of them acts as the Clerk auth
hub (primary), and the rest are Clerk satellites that share sessions.

Covers:
  1. The architecture pattern and why it needs satellite-mode Clerk.
  2. The domain_config.py style config map that drives register_clerk_auth().
  3. The concrete register_clerk_auth() call on each role (primary vs satellite).
  4. clerk_user_id as the cross-database join key, with a multi-db lookup
     example.
  5. Webhook-driven user/plan propagation (one endpoint on the primary).
  6. A live "which role am I?" inspector driven by an env-style switcher.
"""

import json
import os

import dash
import dash_mantine_components as dmc
from dash import Input, Output, State, callback, dcc, html
from dash_iconify import DashIconify

dash.register_page(
    __name__,
    path="/multi-domain",
    name="Multi-domain (galaxy)",
    order=10,
)

# ---------------------------------------------------------------------------
# Domain fixtures — mirror the 2plot galaxy so the demo code reads like the
# real thing. The inspector below "boots" each of these in turn.
# ---------------------------------------------------------------------------
#
# Each domain is its own TLD (not a subdomain). In the 2plot galaxy:
#   2plot.ai      — primary auth hub + admin
#   2plot.store   — e-commerce satellite
#   2plot.me      — user-content satellite
#   2plot.shop    — affiliate satellite
#
# Same container image, DOMAIN_APP env var selects the role at boot.
DOMAINS = {
    "ai": {
        "label": "2plot.ai",
        "role": "primary",
        "purpose": "Auth hub, admin dashboards, platform tools",
        "db": "2plot_ai_db",
        "color": "blue",
        "icon": "tabler:shield-lock",
    },
    "store": {
        "label": "2plot.store",
        "role": "satellite",
        "purpose": "E-commerce: Stripe, inventory, shipping",
        "db": "2plot_store_db",
        "color": "grape",
        "icon": "tabler:shopping-cart",
    },
    "me": {
        "label": "2plot.me",
        "role": "satellite",
        "purpose": "User content: profiles, maps, tilesets",
        "db": "2plot_me_db",
        "color": "teal",
        "icon": "tabler:map",
    },
    "shop": {
        "label": "2plot.shop",
        "role": "satellite",
        "purpose": "Affiliate marketplace",
        "db": "2plot_shop_db",
        "color": "orange",
        "icon": "tabler:affiliate",
    },
}

# ---------------------------------------------------------------------------
# Code snippets — each block is the file as it would ship in production.
# ---------------------------------------------------------------------------
DOMAIN_CONFIG_PY = '''# domain_config.py — drives register_clerk_auth() per role.
#
# Every container boots with DOMAIN_APP=<one-of:ai,store,me,shop>; this map
# decides whether it's the primary auth hub or a satellite. 2plot.ai is
# the primary (hosts sign-in); the other three are satellites.

CLERK_DOMAINS = {
    "ai": {                                    # PRIMARY — 2plot.ai
        "is_satellite": False,
        "satellite_domain": None,
        "sign_in_url": "/sign-in",             # local path — hub hosts sign-in
        "sign_up_url": "/sign-up",
        "allowed_redirect_origins": [
            "https://2plot.store",
            "https://2plot.me",
            "https://2plot.shop",
        ],
    },
    "store": {                                 # SATELLITE — 2plot.store
        "is_satellite": True,
        "satellite_domain": "2plot.store",     # host only, no protocol
        "sign_in_url": "https://2plot.ai/sign-in",
        "sign_up_url": "https://2plot.ai/sign-up",
        "allowed_redirect_origins": [],
    },
    "me": {                                    # SATELLITE — 2plot.me
        "is_satellite": True,
        "satellite_domain": "2plot.me",
        "sign_in_url": "https://2plot.ai/sign-in",
        "sign_up_url": "https://2plot.ai/sign-up",
        "allowed_redirect_origins": [],
    },
    "shop": {                                  # SATELLITE — 2plot.shop
        "is_satellite": True,
        "satellite_domain": "2plot.shop",
        "sign_in_url": "https://2plot.ai/sign-in",
        "sign_up_url": "https://2plot.ai/sign-up",
        "allowed_redirect_origins": [],
    },
}
'''

APP_PY = '''# app.py — one file, all four domains.
import os
from dash import Dash
import dash_mantine_components as dmc
from dash_clerk_auth import register_clerk_auth, configure_app

from domain_config import CLERK_DOMAINS

DOMAIN_APP = os.environ["DOMAIN_APP"]          # "ai" | "store" | "me" | "shop"
cfg = CLERK_DOMAINS[DOMAIN_APP]

register_clerk_auth(
    clerk_secret_key=os.environ["CLERK_SECRET_KEY"],
    clerk_publishable_key=os.environ["CLERK_PUBLISHABLE_KEY"],

    # The Clerk Frontend API origin — same for every domain.
    # REQUIRED in satellite mode; a good idea on the primary too.
    clerk_frontend_api=os.environ["CLERK_FRONTEND_API"],
    # e.g. "https://your-app.clerk.accounts.dev"

    # Role-specific wiring from domain_config.py
    is_satellite=cfg["is_satellite"],
    satellite_domain=cfg["satellite_domain"],
    sign_in_url=cfg["sign_in_url"],
    sign_up_url=cfg["sign_up_url"],
    allowed_redirect_origins=cfg["allowed_redirect_origins"],

    # Satellite apps render their own header avatar — ask the hook to stay
    # out of the way. The clerk-auth-store is still injected.
    headless=True,

    enable_billing=True,
)

app = Dash(__name__, external_stylesheets=[dmc.styles.ALL], use_pages=True)
configure_app(app)
'''

CROSS_DB_LOOKUP = '''# shared/identity.py — clerk_user_id is the universal join key.
from database import get_db_session

def get_user_summary(clerk_user_id: str) -> dict:
    """Fan-out read across every domain DB, keyed by clerk_user_id."""
    with get_db_session("ai") as s:
        user = s.query(User).filter_by(clerk_user_id=clerk_user_id).first()

    with get_db_session("store") as s:
        order_count = s.query(Order).filter_by(clerk_user_id=clerk_user_id).count()

    with get_db_session("me") as s:
        tileset_count = s.query(Tileset).filter_by(clerk_user_id=clerk_user_id).count()

    return {
        "email": user.email if user else None,
        "order_count": order_count,
        "tileset_count": tileset_count,
    }
'''

WEBHOOK_PY = '''# routes/webhooks.py — one webhook endpoint on the PRIMARY.
#
# Clerk only needs to know about one URL (configure it in the Clerk
# dashboard: https://2plot.ai/api/webhooks/clerk). On user / plan
# changes, fan the update out to every DB that stores clerk_user_id.

from flask import request, jsonify
from svix.webhooks import Webhook, WebhookVerificationError

from database import get_db_session, User, Order, Tileset

@app.server.route("/api/webhooks/clerk", methods=["POST"])
def handle_clerk_webhook():
    try:
        event = Webhook(os.environ["CLERK_WEBHOOK_SECRET"]).verify(
            request.get_data(),
            {
                "svix-id": request.headers["svix-id"],
                "svix-timestamp": request.headers["svix-timestamp"],
                "svix-signature": request.headers["svix-signature"],
            },
        )
    except WebhookVerificationError:
        return jsonify(error="bad signature"), 401

    kind = event["type"]
    data = event["data"]

    if kind == "user.deleted":
        uid = data["id"]
        # Anonymise across every domain DB — order history stays, but the
        # clerk_user_id gets tombstoned so a future sign-up can't claim it.
        with get_db_session("ai") as s:
            s.query(User).filter_by(clerk_user_id=uid).delete()
        with get_db_session("store") as s:
            s.query(Order).filter_by(clerk_user_id=uid).update(
                {"clerk_user_id": "__deleted__"}
            )
        with get_db_session("me") as s:
            s.query(Tileset).filter_by(clerk_user_id=uid).update(
                {"clerk_user_id": "__deleted__"}
            )

    elif kind in ("subscription.created", "subscription.updated"):
        # Plan change — write to ai_db, the other domains read it live from
        # the JWT via clerk-auth-store.plan. No cross-DB write needed.
        uid = data.get("user_id") or data.get("subscriber_user_id")
        plan = data.get("plan", {}).get("slug", "free")
        with get_db_session("ai") as s:
            user = s.query(User).filter_by(clerk_user_id=uid).first()
            if user:
                user.plan = plan

    return jsonify(received=True), 200
'''

HEADLESS_HEADER = '''# shared/layout/shell.py — rendering your own avatar when headless=True.
import dash_mantine_components as dmc
from dash import Input, Output, State, callback, clientside_callback, html
from dash_iconify import DashIconify

def build_header():
    return dmc.AppShellHeader(
        dmc.Group(
            [
                dmc.Text("2plot.ai", fw=700),
                # Your own avatar. Clerk JS hydrates it on session change.
                dmc.Menu(
                    [
                        dmc.MenuTarget(
                            dmc.Avatar(id="app-avatar", src=None, radius="xl")
                        ),
                        dmc.MenuDropdown(
                            [
                                dmc.MenuItem(
                                    "Sign in", id="app-signin", n_clicks=0
                                ),
                                dmc.MenuItem(
                                    "Manage profile", id="app-profile", n_clicks=0
                                ),
                                dmc.MenuDivider(),
                                dmc.MenuItem(
                                    "Sign out", id="app-signout", n_clicks=0,
                                    color="red",
                                ),
                            ]
                        ),
                    ]
                ),
            ],
            justify="space-between",
            px="md",
        )
    )

# Drive the avatar src from clerk-auth-store (populated by the hook).
@callback(
    Output("app-avatar", "src"),
    Input("clerk-auth-store", "data"),
)
def _avatar_src(auth):
    return (auth or {}).get("image_url") or None

# Hand menu actions off to window.Clerk (already loaded by the hook).
clientside_callback(
    "n => n && window.Clerk.openSignIn({afterSignInUrl: window.location.href})",
    Output("app-signin", "n_clicks"), Input("app-signin", "n_clicks"),
    prevent_initial_call=True,
)
clientside_callback(
    "n => n && window.Clerk.openUserProfile()",
    Output("app-profile", "n_clicks"), Input("app-profile", "n_clicks"),
    prevent_initial_call=True,
)
clientside_callback(
    "n => n && window.Clerk.signOut().then(() => window.location.reload())",
    Output("app-signout", "n_clicks"), Input("app-signout", "n_clicks"),
    prevent_initial_call=True,
)
'''


# ---------------------------------------------------------------------------
# UI helpers
# ---------------------------------------------------------------------------
def _domain_tile(key, d):
    return dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        dmc.ThemeIcon(
                            DashIconify(icon=d["icon"], width=20),
                            color=d["color"],
                            variant="light",
                            size="lg",
                            radius="md",
                        ),
                        dmc.Stack(
                            [
                                dmc.Text(d["label"], fw=600, size="sm"),
                                dmc.Badge(
                                    d["role"].upper(),
                                    size="xs",
                                    variant="filled" if d["role"] == "primary" else "light",
                                    color=d["color"],
                                ),
                            ],
                            gap=2,
                        ),
                    ],
                    gap="sm",
                ),
                dmc.Text(d["purpose"], size="xs", c="dimmed"),
                dmc.Code(f"DOMAIN_APP={key}", style={"fontSize": 10}),
                dmc.Code(d["db"], style={"fontSize": 10}),
            ],
            gap="xs",
        ),
        p="md",
        radius="md",
        withBorder=True,
        style={"height": "100%"},
    )


def _flow_step(num, label, detail, icon):
    return dmc.Group(
        [
            dmc.Badge(num, size="lg", variant="filled", radius="sm"),
            dmc.ThemeIcon(
                DashIconify(icon=icon, width=18),
                variant="light",
                color="blue",
                size="md",
                radius="md",
            ),
            dmc.Stack(
                [dmc.Text(label, fw=600, size="sm"), dmc.Text(detail, size="xs", c="dimmed")],
                gap=0,
            ),
        ],
        gap="sm",
        align="flex-start",
        wrap="nowrap",
    )


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------
layout = dmc.Stack(
    [
        dmc.Title("Multi-domain (satellite galaxy)", order=1),
        dmc.Text(
            "Running dash-clerk-auth across a constellation of related "
            "domains — a central auth hub (primary) plus N satellites — so "
            "users sign in once and every sibling recognises them.",
            c="dimmed",
        ),
        # The architecture tiles
        dmc.Title("1. The architecture", order=2, mt="md"),
        dmc.Text(
            "Four containers, one codebase, one Clerk application. DOMAIN_APP "
            "selects the role at boot. Every domain has its own Postgres and "
            "its own Flask session store — the only thing that crosses "
            "domain boundaries is the Clerk JWT and the clerk_user_id it "
            "carries.",
            size="sm",
        ),
        dmc.SimpleGrid(
            [_domain_tile(k, d) for k, d in DOMAINS.items()],
            cols={"base": 1, "sm": 2, "lg": 4},
            spacing="md",
        ),
        dmc.Alert(
            dmc.Text(
                "Clerk's satellite-domains feature (opt-in via "
                "isSatellite / domain / signInUrl on Clerk.load()) is what "
                "makes a single sign-in on the primary flow through to "
                "store / me / shop without re-authenticating. dash-clerk-auth "
                "exposes this as first-class kwargs on register_clerk_auth(). "
                "The v0.7 __dca_identity cookie is per-domain — each satellite "
                "verifies and caches the Clerk verdict locally.",
                size="sm",
            ),
            title="Why satellite mode matters",
            color="blue",
            icon=DashIconify(icon="tabler:satellite"),
        ),
        # Role inspector
        dmc.Title("2. Pick a role, see the config", order=2, mt="md"),
        dmc.Text(
            "Switch between 'primary' and each satellite to see the "
            "register_clerk_auth() call that domain ships — and the "
            "Clerk.load() options your browser would receive.",
            size="sm",
        ),
        dmc.Paper(
            dmc.Stack(
                [
                    dmc.SegmentedControl(
                        id="multi-domain-role",
                        data=[
                            {"label": f"{k} ({d['role']})", "value": k}
                            for k, d in DOMAINS.items()
                        ],
                        value="ai",
                        fullWidth=True,
                    ),
                    html.Div(id="multi-domain-inspector"),
                ],
                gap="md",
            ),
            p="lg",
            radius="md",
            withBorder=True,
        ),
        # Config-driven wiring
        dmc.Title("3. Drive it from a single config map", order=2, mt="md"),
        dmc.Text(
            "Keep every domain's role wiring in one dict so adding a fifth "
            "satellite is a two-line diff.",
            size="sm",
        ),
        dmc.CodeHighlight(code=DOMAIN_CONFIG_PY, language="python"),
        dmc.Title("4. The shared app.py", order=3, mt="sm"),
        dmc.Text(
            "One app.py, DOMAIN_APP selects the role. register_clerk_auth() "
            "gets called once per boot — hooks fire during Dash construction, "
            "so this must happen before Dash(...).",
            size="sm",
        ),
        dmc.CodeHighlight(code=APP_PY, language="python"),
        # User flow
        dmc.Title("5. Cross-domain sign-in flow", order=2, mt="md"),
        dmc.Paper(
            dmc.Stack(
                [
                    _flow_step(
                        "1",
                        "User lands on 2plot.store (satellite)",
                        "clerk-auth-store is empty — no active session in this browser.",
                        "tabler:browser",
                    ),
                    _flow_step(
                        "2",
                        "User clicks sign-in, redirected to 2plot.ai",
                        "Satellite's Clerk.load({signInUrl}) sends them to the primary.",
                        "tabler:arrow-right",
                    ),
                    _flow_step(
                        "3",
                        "Clerk authenticates on the hub",
                        "Primary sets the Clerk first-party cookie and issues a JWT.",
                        "tabler:key",
                    ),
                    _flow_step(
                        "4",
                        "Redirect back with __clerk_db_jwt",
                        "Satellite sees the JWT in the URL, hydrates its own Clerk session.",
                        "tabler:arrow-left",
                    ),
                    _flow_step(
                        "5",
                        "clerk-auth-store populates",
                        "Every callback in the satellite wakes up with the same user_id.",
                        "tabler:database",
                    ),
                    _flow_step(
                        "6",
                        "Sibling visits recognised automatically",
                        "Opening 2plot.me in a new tab hits the same Clerk session.",
                        "tabler:check",
                    ),
                ],
                gap="sm",
            ),
            p="lg",
            radius="md",
            withBorder=True,
        ),
        # Cross-DB pattern
        dmc.Title("6. clerk_user_id is the cross-database join key", order=2, mt="md"),
        dmc.Text(
            "Each satellite owns its own Postgres; there are no FKs across "
            "databases. Instead, every user-owned table carries a string "
            "clerk_user_id column, populated from auth_data['user_id'] on write "
            "and queried on read. Fan-out reads live in a shared service layer.",
            size="sm",
        ),
        dmc.CodeHighlight(code=CROSS_DB_LOOKUP, language="python"),
        # Webhooks
        dmc.Title("7. One webhook endpoint, N databases", order=2, mt="md"),
        dmc.Text(
            "Configure Clerk's webhook to hit the primary's URL. On "
            "user.deleted / subscription.* events, fan the change out to "
            "each domain's DB. Plan changes don't need a DB write on the "
            "satellites — they read the JWT's plan claim live via "
            "clerk-auth-store.",
            size="sm",
        ),
        dmc.CodeHighlight(code=WEBHOOK_PY, language="python"),
        # Headless avatar
        dmc.Title("8. Rendering your own avatar (headless=True)", order=2, mt="md"),
        dmc.Text(
            "Most satellite apps already have a dmc-styled header with its "
            "own avatar slot. Pass headless=True and the hook stays out of "
            "your way — you wire your menu to window.Clerk directly.",
            size="sm",
        ),
        dmc.CodeHighlight(code=HEADLESS_HEADER, language="python"),
        # Summary
        dmc.Title("9. Checklist for a new satellite", order=2, mt="md"),
        dmc.Paper(
            dmc.List(
                [
                    dmc.ListItem("Add the subdomain to Clerk Dashboard → Domains → Satellites."),
                    dmc.ListItem("Whitelist its origin in your primary's allowed_redirect_origins."),
                    dmc.ListItem("Set CLERK_FRONTEND_API to your Clerk-hosted origin on every container."),
                    dmc.ListItem("Add the domain to CLERK_DOMAINS in domain_config.py."),
                    dmc.ListItem("Ship — no code change needed beyond that map."),
                    dmc.ListItem("Carry clerk_user_id on any new DB table that needs per-user scoping."),
                    dmc.ListItem("Add webhook handlers if the new domain has a DB that stores clerk_user_id."),
                ],
                size="sm",
                spacing="xs",
            ),
            p="lg",
            radius="md",
            withBorder=True,
        ),
        dmc.Alert(
            dmc.Text(
                "Reference implementation: github.com/pip-install-python/2plot. "
                "Same exact pattern across 2plot.ai (primary), 2plot.store, "
                "2plot.me (satellites), with three Postgres databases and a "
                "single Clerk application.",
                size="sm",
            ),
            title="Living example",
            color="blue",
            icon=DashIconify(icon="mdi:github"),
        ),
    ],
    gap="md",
)


# ---------------------------------------------------------------------------
# Inspector callback — renders the register_clerk_auth call and the
# Clerk.load() options for the currently-selected role.
# ---------------------------------------------------------------------------
def _render_role(role_key):
    d = DOMAINS[role_key]
    is_primary = d["role"] == "primary"

    if is_primary:
        kwargs = {
            "clerk_sign_in_url": "/sign-in",
            "sign_up_url": "/sign-up",
            "clerk_frontend_api": "https://your-app.clerk.accounts.dev",
            "is_satellite": False,
            "allowed_redirect_origins": [
                f"https://{DOMAINS[k]['label']}"
                for k in DOMAINS
                if DOMAINS[k]["role"] == "satellite"
            ],
            "headless": True,
            "enable_billing": True,
        }
    else:
        kwargs = {
            "clerk_sign_in_url": "https://2plot.ai/sign-in",
            "sign_up_url": "https://2plot.ai/sign-up",
            "clerk_frontend_api": "https://your-app.clerk.accounts.dev",
            "is_satellite": True,
            "satellite_domain": d["label"],
            "headless": True,
            "enable_billing": True,
        }

    # Build the register_clerk_auth call snippet
    def _fmt(v):
        return json.dumps(v) if not isinstance(v, list) else json.dumps(v)

    call_lines = [
        "register_clerk_auth(",
        '    clerk_secret_key=os.environ["CLERK_SECRET_KEY"],',
        '    clerk_publishable_key=os.environ["CLERK_PUBLISHABLE_KEY"],',
    ]
    for k, v in kwargs.items():
        if v is False:
            continue  # skip False defaults for readability
        if isinstance(v, list):
            call_lines.append(f"    {k}={_fmt(v)},")
        else:
            call_lines.append(f"    {k}={_fmt(v)},")
    call_lines.append(")")
    register_snippet = "\n".join(call_lines)

    # Build the Clerk.load() options snippet (what the browser receives)
    if is_primary:
        load_opts = {
            "appearance": "... (liquid glass theme, trimmed)",
            "allowedRedirectOrigins": kwargs["allowed_redirect_origins"],
        }
    else:
        load_opts = {
            "appearance": "... (liquid glass theme, trimmed)",
            "isSatellite": True,
            "domain": kwargs["satellite_domain"],
            "signInUrl": kwargs["clerk_sign_in_url"],
            "signUpUrl": kwargs["sign_up_url"],
        }
    load_snippet = "Clerk.load(\n    " + json.dumps(load_opts, indent=4).replace("\n", "\n    ") + "\n);"

    return dmc.Stack(
        [
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon=d["icon"], width=20),
                        color=d["color"],
                        variant="light",
                        size="lg",
                        radius="md",
                    ),
                    dmc.Text(d["label"], fw=700, size="lg"),
                    dmc.Badge(
                        d["role"].upper(),
                        color=d["color"],
                        variant="filled" if is_primary else "light",
                    ),
                ],
                gap="sm",
            ),
            dmc.Tabs(
                [
                    dmc.TabsList(
                        [
                            dmc.TabsTab(
                                "register_clerk_auth()",
                                value="py",
                                leftSection=DashIconify(icon="tabler:brand-python", width=14),
                            ),
                            dmc.TabsTab(
                                "Clerk.load() options",
                                value="js",
                                leftSection=DashIconify(icon="tabler:brand-javascript", width=14),
                            ),
                        ]
                    ),
                    dmc.TabsPanel(
                        dmc.CodeHighlight(code=register_snippet, language="python"),
                        value="py",
                        pt="sm",
                    ),
                    dmc.TabsPanel(
                        dmc.CodeHighlight(code=load_snippet, language="javascript"),
                        value="js",
                        pt="sm",
                    ),
                ],
                value="py",
            ),
        ],
        gap="sm",
    )


@callback(
    Output("multi-domain-inspector", "children"),
    Input("multi-domain-role", "value"),
)
def _inspector(role_key):
    if not role_key or role_key not in DOMAINS:
        role_key = "ai"
    return _render_role(role_key)