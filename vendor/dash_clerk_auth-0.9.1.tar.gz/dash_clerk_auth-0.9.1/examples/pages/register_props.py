"""
register_clerk_auth() — props explorer.

Documents every keyword argument with its type, default, and effect. Kept
deliberately static (no live wiring) because the function must run before the
Dash app is constructed.
"""

import dash
import dash_mantine_components as dmc
from dash import html
from dash_iconify import DashIconify

dash.register_page(__name__, path="/register-props", name="register_clerk_auth props", order=2)

MENU_IN_HEADER = '''from dash_clerk_auth import register_clerk_auth, create_clerk_menu
import dash_mantine_components as dmc

register_clerk_auth(..., headless=True)   # suppress the fixed-position UI

dmc.AppShellHeader(
    dmc.Group(
        [
            dmc.Title("My app"),
            create_clerk_menu(),          # avatar + dropdown, in the header
        ],
        justify="space-between",
        h="100%",
        px="md",
    )
)
'''

PROPS = [
    {
        "name": "clerk_secret_key",
        "type": "str",
        "default": "os.environ['CLERK_SECRET_KEY']",
        "required": True,
        "desc": (
            "Your Clerk backend API secret. Used for server-side token verification "
            "via the clerk-backend-api SDK. Never ship this to the browser."
        ),
    },
    {
        "name": "clerk_publishable_key",
        "type": "str",
        "default": "os.environ['CLERK_PUBLISHABLE_KEY']",
        "required": True,
        "desc": (
            "Your Clerk publishable key. Embedded in the injected <script> tag so "
            "clerk.browser.js can boot on the client. Safe to expose."
        ),
    },
    {
        "name": "clerk_sign_in_url",
        "type": "str",
        "default": "os.environ['CLERK_SIGN_IN_URL']",
        "required": True,
        "desc": (
            "Full URL to your Clerk sign-in page (e.g. "
            "https://your-app.clerk.accounts.dev/sign-in). The domain portion is "
            "also used to source clerk-js from your Clerk frontend API host."
        ),
    },
    {
        "name": "session_secret",
        "type": "str",
        "default": "os.environ.get('SESSION_SECRET') or os.environ.get('FLASK_SECRET_KEY', 'default-dev-secret-key')",
        "required": False,
        "desc": (
            "v0.6+ canonical name (replaces flask_secret_key, which is kept as a "
            "deprecated alias). Signs (a) Flask session cookies and Starlette "
            "SessionMiddleware on FastAPI, AND (b) the v0.7 __dca_identity "
            "verified-positive cache cookie. Set to a long random value in "
            "production and keep it out of source control."
        ),
    },
    {
        "name": "flask_secret_key",
        "type": "str",
        "default": "(deprecated; use session_secret)",
        "required": False,
        "desc": (
            "DEPRECATED in 0.6 — backwards-compat alias for session_secret. Emits "
            "a DeprecationWarning when used. Will be removed in a future major."
        ),
    },
    {
        "name": "session_lifetime_days",
        "type": "int",
        "default": "7",
        "required": False,
        "desc": (
            "How long the session AND the v0.7 __dca_identity cookie remain "
            "valid. Maps to Flask PERMANENT_SESSION_LIFETIME and Starlette "
            "SessionMiddleware max_age. The identity cookie's signature carries "
            "its own timestamp so a stale cookie is rejected even if the browser "
            "kept it past this window."
        ),
    },
    {
        "name": "backend",
        "type": "str",
        "default": '"auto"',
        "required": False,
        "desc": (
            "v0.6+. One of \"auto\" (default), \"flask\", \"fastapi\", \"quart\". "
            "\"auto\" detects from app.server when configure_app(app) runs. "
            "Override when autodetection fails (custom server subclass, etc.)."
        ),
    },
    {
        "name": "on_unverified",
        "type": "str",
        "default": '"forbidden"',
        "required": False,
        "desc": (
            "v0.6+. Layout-decorator default policy when Clerk can't verify. "
            "\"forbidden\" (fail-closed, default), \"allow\" (fail-open), "
            "\"passthrough\" (legacy v0.5 — render both protected layout and "
            "placeholder, let client gate hide one). Per-decorator overrides "
            "available via on_inconclusive= kwarg on each layout decorator."
        ),
    },
    {
        "name": "verify_timeout",
        "type": "float",
        "default": "5.0",
        "required": False,
        "desc": (
            "v0.6+. Per-request Clerk verify timeout in seconds. The first hit "
            "after a cache miss can JWKS-roundtrip; this caps how long the "
            "ASGI middleware waits before falling back to anonymous. Once the "
            "v0.7 __dca_identity cookie is set, subsequent hits skip this entirely."
        ),
    },
    {
        "name": "authorized_parties",
        "type": "List[str] | None",
        "default": "None",
        "required": False,
        "desc": (
            "v0.6+. Optional Clerk authorized_parties whitelist (passed to "
            "authenticate_request). When set, Clerk rejects JWTs whose azp "
            "claim isn't in the list — useful when serving multiple subdomains."
        ),
    },
    {
        "name": "debug",
        "type": "bool",
        "default": "False (falls back to DEBUG env var)",
        "required": False,
        "desc": (
            "Enables verbose logging from the hook and, by default, turns on the "
            "debug panel. Keep off in production."
        ),
    },
    {
        "name": "show_debug_panel",
        "type": "bool | None",
        "default": "None → mirrors `debug`",
        "required": False,
        "desc": (
            "Force the in-browser debug panel on or off. Set to False in staging "
            "if you want logs without the UI panel."
        ),
    },
    {
        "name": "enable_proxy_fix",
        "type": "bool",
        "default": "True",
        "required": False,
        "desc": (
            "Wraps server.wsgi_app with werkzeug.middleware.proxy_fix.ProxyFix so "
            "X-Forwarded-* headers from a reverse proxy (nginx, Cloudflare, etc.) "
            "are respected. Disable if you terminate TLS directly on the Flask server."
        ),
    },
    {
        "name": "enable_billing",
        "type": "bool",
        "default": "False",
        "required": False,
        "desc": (
            "Flips on Clerk Billing support — @require_plan / @require_feature "
            "start working, the clerk-auth-store payload gains `plan` and "
            "`features` keys, and the debug panel renders plan info. Requires a "
            "Clerk application with Billing enabled."
        ),
    },
    {
        "name": "headless",
        "type": "bool",
        "default": "False",
        "required": False,
        "desc": (
            "When True, the hook does NOT inject its default top-right "
            "avatar / dropdown. Use this when your app renders its own "
            "user controls (e.g. a dmc.Menu in the header). The "
            "clerk-auth-store and underlying components are still injected."
        ),
    },
    {
        "name": "is_satellite",
        "type": "bool",
        "default": "False",
        "required": False,
        "desc": (
            "Flip to True on every satellite domain in a multi-domain galaxy. "
            "See the Multi-domain demo page for the full recipe."
        ),
    },
    {
        "name": "satellite_domain",
        "type": "str | None",
        "default": "None",
        "required": False,
        "desc": (
            "Host-only (no protocol) for this satellite, e.g. "
            "'store.example.com'. Required when is_satellite=True."
        ),
    },
    {
        "name": "sign_up_url",
        "type": "str | None",
        "default": "os.environ.get('CLERK_SIGN_UP_URL', '')",
        "required": False,
        "desc": (
            "Absolute URL of the primary's sign-up page. Passed to "
            "Clerk.load() as signUpUrl so satellites redirect there for "
            "registration."
        ),
    },
    {
        "name": "clerk_frontend_api",
        "type": "str | None",
        "default": "os.environ.get('CLERK_FRONTEND_API', '')",
        "required": False,
        "desc": (
            "The Clerk-hosted Frontend API origin "
            "(https://your-app.clerk.accounts.dev). In satellite mode the "
            "sign-in URL points at your primary app, so the hook can't "
            "infer the clerk.browser.js source origin — set this explicitly."
        ),
    },
    {
        "name": "allowed_redirect_origins",
        "type": "list[str] | None",
        "default": "None",
        "required": False,
        "desc": (
            "On the primary, the whitelist of satellite origins Clerk may "
            "redirect back to after sign-in. Passed to Clerk.load() as "
            "allowedRedirectOrigins."
        ),
    },
    {
        "name": "sign_in_url",
        "type": "str | None",
        "default": "None (alias for clerk_sign_in_url)",
        "required": False,
        "desc": (
            "Alias for clerk_sign_in_url — matches Clerk JS naming. If "
            "both are given, sign_in_url wins."
        ),
    },
    {
        "name": "app",
        "type": "Dash | None",
        "default": "None",
        "required": False,
        "desc": (
            "Convenience: pass your Dash app to call configure_app() "
            "automatically after registration. Equivalent to calling both "
            "functions yourself."
        ),
    },
]

REGISTRATION_EXAMPLE = """from dash_clerk_auth import register_clerk_auth

register_clerk_auth(
    # --- required ---
    clerk_secret_key="sk_test_...",
    clerk_publishable_key="pk_test_...",
    clerk_sign_in_url="https://your-app.clerk.accounts.dev/sign-in",

    # --- session + identity cookie (v0.7) ---
    session_secret="a-long-random-string",   # signs sessions AND __dca_identity
    session_lifetime_days=14,

    # --- backend (v0.6) ---
    backend="auto",                # detects flask/fastapi/quart from app.server
    on_unverified="forbidden",     # fail-closed default for layout decorators
    verify_timeout=5.0,
    authorized_parties=["https://app.example.com"],   # optional Clerk azp whitelist

    # --- dev ergonomics ---
    debug=True,
    show_debug_panel=True,

    # --- production concerns ---
    enable_proxy_fix=True,

    # --- billing ---
    enable_billing=True,
)

# --- (v0.7, Dash 4.2 + FastAPI/Quart only) opt-in WebSocket auth ---
# from dash_clerk_auth import register_websocket_auth
# register_websocket_auth(on_anonymous="allow")  # mixed-traffic safe; default
"""


def _prop_row(prop):
    return dmc.TableTr(
        [
            dmc.TableTd(
                dmc.Group(
                    [
                        dmc.Code(prop["name"]),
                        dmc.Badge("required", color="red", size="xs", variant="filled") if prop["required"] else None,
                    ],
                    gap=6,
                )
            ),
            dmc.TableTd(dmc.Code(prop["type"])),
            dmc.TableTd(dmc.Code(prop["default"], style={"fontSize": 11})),
            dmc.TableTd(dmc.Text(prop["desc"], size="sm")),
        ]
    )


layout = dmc.Stack(
    [
        dmc.Title("register_clerk_auth() props", order=1),
        dmc.Text(
            "The single entry point that wires Clerk into your Dash app. Call it "
            "before constructing the Dash object so the @hooks.index() and "
            "@hooks.layout() handlers fire during app build.",
            c="dimmed",
        ),
        dmc.Paper(
            dmc.Table(
                [
                    dmc.TableThead(
                        dmc.TableTr(
                            [
                                dmc.TableTh("Prop"),
                                dmc.TableTh("Type"),
                                dmc.TableTh("Default"),
                                dmc.TableTh("What it does"),
                            ]
                        )
                    ),
                    dmc.TableTbody([_prop_row(p) for p in PROPS]),
                ],
                striped=True,
                highlightOnHover=True,
                withTableBorder=True,
                withColumnBorders=False,
            ),
            p="md",
            radius="md",
            withBorder=True,
        ),
        dmc.Title("Full-featured example", order=3, mt="lg"),
        dmc.CodeHighlight(code=REGISTRATION_EXAMPLE, language="python"),
        dmc.Alert(
            dmc.Stack(
                [
                    dmc.Text(
                        "v0.6 added first-class FastAPI/Quart support. The package now "
                        "imports cleanly without Flask installed; configure_app() "
                        "autodetects the backend from app.server (Flask vs FastAPI vs Quart) "
                        "and installs the right session machinery. Pass backend=\"flask\" "
                        "or backend=\"fastapi\" to override the detection.",
                        size="sm",
                    ),
                    dmc.Text(
                        "v0.7 added the signed __dca_identity cookie (verified-positive "
                        "cache for the Clerk verdict) AND made ClerkASGIMiddleware handle "
                        "WebSocket scope so Dash 4.2 WS-served callbacks see the verified "
                        "user. Pass session_secret= to enable cookie minting; without it "
                        "the package falls back to per-request Clerk JWKS verification.",
                        size="sm",
                    ),
                ],
                gap="xs",
            ),
            title="Backend coverage (0.6) and identity cookie (0.7)",
            color="blue",
            icon=DashIconify(icon="tabler:info-circle"),
        ),
        # -------------------------------------------------------------------
        # Companion helper — create_clerk_menu()
        # -------------------------------------------------------------------
        dmc.Title("Companion helper: create_clerk_menu()", order=3, mt="xl"),
        dmc.Text(
            "Pair headless=True with this helper to drop the liquid-glass "
            "avatar + dropdown directly into your dmc.AppShellHeader "
            "instead of the fixed top-right corner. This demo app uses "
            "exactly this pattern — look at the avatar in the header above.",
            size="sm",
        ),
        dmc.CodeHighlight(code=MENU_IN_HEADER, language="python"),
        dmc.Paper(
            dmc.Table(
                [
                    dmc.TableThead(
                        dmc.TableTr(
                            [
                                dmc.TableTh("Arg"),
                                dmc.TableTh("Default"),
                                dmc.TableTh("What it does"),
                            ]
                        )
                    ),
                    dmc.TableTbody(
                        [
                            dmc.TableTr(
                                [
                                    dmc.TableTd(dmc.Code("show_dropdown")),
                                    dmc.TableTd(dmc.Code("True")),
                                    dmc.TableTd(
                                        dmc.Text(
                                            "When False, returns just the bare avatar "
                                            "(no built-in menu). Useful when you want "
                                            "to wrap it in your own dmc.Menu / Popover.",
                                            size="sm",
                                        )
                                    ),
                                ]
                            ),
                            dmc.TableTr(
                                [
                                    dmc.TableTd(dmc.Code("dropdown_align")),
                                    dmc.TableTd(dmc.Code("'right'")),
                                    dmc.TableTd(
                                        dmc.Text(
                                            "'right' anchors the dropdown to the right "
                                            "edge of the avatar (default — right-side "
                                            "header). Pass 'left' for avatars placed on "
                                            "the left side of a header.",
                                            size="sm",
                                        )
                                    ),
                                ]
                            ),
                        ]
                    ),
                ],
                withTableBorder=True,
                striped=True,
            ),
            p="md",
            radius="md",
            withBorder=True,
        ),
    ],
    gap="md",
)