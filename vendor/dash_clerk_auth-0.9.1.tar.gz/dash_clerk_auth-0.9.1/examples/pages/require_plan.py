"""
@require_plan — gate callbacks on Clerk Billing plan membership.

Requires register_clerk_auth(enable_billing=True). Reads the `plan` claim
from the Clerk JWT and matches it (case-insensitive) against the allow-list.
"""

import dash
import dash_mantine_components as dmc
from dash import Input, Output, State, callback, html, no_update
from dash_iconify import DashIconify

dash.register_page(__name__, path="/require-plan", name="@require_plan", order=5)

SINGLE_PLAN = '''from dash_clerk_auth import require_plan

@callback(
    Output("pro-feature", "children"),
    Input("pro-btn", "n_clicks"),
    prevent_initial_call=True,
)
@require_plan("pro")
def pro_only(n):
    return "Welcome to the Pro feature!"
'''

MULTI_PLAN = '''@callback(
    Output("advanced-report", "children"),
    Input("report-btn", "n_clicks"),
    prevent_initial_call=True,
)
@require_plan(["pro", "enterprise"])   # accept either plan
def advanced_report(n):
    return generate_report()
'''

CALLBACK_PATTERN = '''# For UI gating, read clerk-auth-store.plan directly:
@callback(
    Output("pro-card", "style"),
    Input("clerk-auth-store", "data"),
)
def blur_if_not_pro(auth):
    plan = (auth or {}).get("plan", "free")
    if plan != "pro":
        return {"filter": "blur(4px)", "pointerEvents": "none"}
    return {}
'''

PLANS = [
    {
        "name": "Free",
        "color": "gray",
        "icon": "tabler:user",
        "desc": "Default for every new sign-up.",
        "access": ["Public content", "Basic dashboards"],
        "denied": ["Pro reports", "Enterprise SLA"],
    },
    {
        "name": "Pro",
        "color": "blue",
        "icon": "tabler:diamond",
        "desc": "@require_plan('pro') — single plan allow-list.",
        "access": ["Public content", "Basic dashboards", "Pro reports"],
        "denied": ["Enterprise SLA"],
    },
    {
        "name": "Enterprise",
        "color": "grape",
        "icon": "tabler:crown",
        "desc": "@require_plan(['pro', 'enterprise']) — multi-plan allow-list.",
        "access": ["Public content", "Basic dashboards", "Pro reports", "Enterprise SLA"],
        "denied": [],
    },
]


def _plan_card(plan):
    return dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        dmc.ThemeIcon(
                            DashIconify(icon=plan["icon"], width=22),
                            color=plan["color"],
                            variant="light",
                            size="xl",
                            radius="md",
                        ),
                        dmc.Text(plan["name"], fw=700, size="lg"),
                    ],
                    gap="sm",
                ),
                dmc.Text(plan["desc"], size="xs", c="dimmed", ff="monospace"),
                dmc.Divider(),
                dmc.Stack(
                    [
                        *[
                            dmc.Group(
                                [
                                    DashIconify(icon="tabler:check", width=16, color="var(--mantine-color-green-6)"),
                                    dmc.Text(access, size="sm"),
                                ],
                                gap=6,
                            )
                            for access in plan["access"]
                        ],
                        *[
                            dmc.Group(
                                [
                                    DashIconify(icon="tabler:x", width=16, color="var(--mantine-color-red-6)"),
                                    dmc.Text(denied, size="sm", c="dimmed"),
                                ],
                                gap=6,
                            )
                            for denied in plan["denied"]
                        ],
                    ],
                    gap=6,
                ),
            ],
            gap="sm",
        ),
        p="lg",
        radius="md",
        withBorder=True,
        style={"height": "100%"},
    )


layout = dmc.Stack(
    [
        dmc.Title("@require_plan", order=1),
        dmc.Text(
            "Gate a callback on the user's Clerk Billing plan. Requires the hook to "
            "be registered with enable_billing=True so the JWT's `plan` claim is "
            "parsed into clerk-auth-store.",
            c="dimmed",
        ),
        dmc.SimpleGrid([_plan_card(p) for p in PLANS], cols={"base": 1, "md": 3}, spacing="md"),
        # Live demo
        dmc.Paper(
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="tabler:diamond", width=20),
                            dmc.Text("Live demo", fw=600),
                        ],
                        gap="sm",
                    ),
                    dmc.Text(
                        "Tries to load a Pro-only feature. Your current plan comes from "
                        "clerk-auth-store.plan — if Clerk Billing isn't set up, plan "
                        "defaults to 'free'.",
                        size="sm",
                        c="dimmed",
                    ),
                    dmc.Button(
                        "Load Pro feature",
                        id="require-plan-btn",
                        leftSection=DashIconify(icon="tabler:diamond", width=16),
                        color="blue",
                    ),
                    html.Div(id="require-plan-output"),
                ],
                gap="sm",
            ),
            p="lg",
            radius="md",
            withBorder=True,
        ),
        # Code
        dmc.Title("Single-plan gate", order=3, mt="md"),
        dmc.CodeHighlight(code=SINGLE_PLAN, language="python"),
        dmc.Title("Multiple allowed plans", order=3, mt="md"),
        dmc.CodeHighlight(code=MULTI_PLAN, language="python"),
        dmc.Title("Callback-driven UI (recommended for soft blur)", order=3, mt="md"),
        dmc.Text(
            "@require_plan blocks execution. For visual gating (blur, upgrade "
            "CTA, lock icon) read the plan from clerk-auth-store and branch in "
            "the layout instead — that way the user sees something meaningful.",
            size="sm",
        ),
        dmc.CodeHighlight(code=CALLBACK_PATTERN, language="python"),
    ],
    gap="md",
)


@callback(
    Output("require-plan-output", "children"),
    Input("require-plan-btn", "n_clicks"),
    State("clerk-auth-store", "data"),
    prevent_initial_call=True,
)
def _try_pro(n, auth):
    plan = ((auth or {}).get("plan") or "free").lower()
    user = (auth or {}).get("first_name") or (auth or {}).get("email") or "guest"

    if not auth or not auth.get("user_id"):
        return dmc.Alert(
            "Sign in to see your plan-gated content.",
            color="yellow",
            icon=DashIconify(icon="tabler:alert-triangle"),
            mt="sm",
        )

    if plan in ("pro", "enterprise"):
        return dmc.Alert(
            dmc.Stack(
                [
                    dmc.Text(f"Unlocked for {user}", fw=600),
                    dmc.Text(f"plan = '{plan}' — matched @require_plan(['pro', 'enterprise'])", size="sm"),
                ],
                gap=4,
            ),
            color="green",
            icon=DashIconify(icon="tabler:diamond"),
            mt="sm",
        )

    return dmc.Alert(
        dmc.Stack(
            [
                dmc.Text(f"Upgrade required", fw=600),
                dmc.Text(
                    f"Your current plan is '{plan}'. @require_plan('pro') blocked this callback. "
                    f"In a real app you'd render an upgrade CTA here.",
                    size="sm",
                ),
            ],
            gap=4,
        ),
        color="orange",
        icon=DashIconify(icon="tabler:lock"),
        mt="sm",
    )