"""
@require_feature — gate callbacks on a Clerk Billing feature flag.

Features are finer-grained than plans: one user on 'pro' might have
`advanced_alerts` while another doesn't. Reads the `features` claim from
the Clerk JWT (injected when register_clerk_auth(enable_billing=True)).
"""

import dash
import dash_mantine_components as dmc
from dash import Input, Output, State, callback, html
from dash_iconify import DashIconify

dash.register_page(__name__, path="/require-feature", name="@require_feature", order=6)

DECORATOR = '''from dash_clerk_auth import require_feature

@callback(
    Output("alerts-panel", "children"),
    Input("alerts-btn", "n_clicks"),
    prevent_initial_call=True,
)
@require_feature("advanced_alerts")
def show_alerts(n):
    return render_advanced_alerts()
'''

HAS_FEATURE = '''from dash_clerk_auth import has_feature

# Use has_feature for conditional UI — e.g. hiding a menu item entirely.
if has_feature("advanced_alerts"):
    menu.append(dmc.NavLink(label="Alerts", href="/alerts"))
'''

FEATURES = [
    {"name": "charts_export", "desc": "Download dashboards as CSV / PDF."},
    {"name": "advanced_alerts", "desc": "Custom alert rules, Slack/webhook delivery."},
    {"name": "sso_saml", "desc": "Enterprise single-sign-on via SAML."},
    {"name": "api_access", "desc": "Programmatic access to your data via REST API."},
]


def _feature_row(feat):
    return dmc.TableTr(
        [
            dmc.TableTd(dmc.Code(feat["name"])),
            dmc.TableTd(dmc.Text(feat["desc"], size="sm")),
            dmc.TableTd(
                html.Div(id={"type": "feature-check", "name": feat["name"]}),
            ),
        ]
    )


layout = dmc.Stack(
    [
        dmc.Title("@require_feature", order=1),
        dmc.Text(
            "Protect a callback on a single Clerk feature flag. Features are an "
            "array claim on the JWT — so the same 'pro' plan can have different "
            "features for different users.",
            c="dimmed",
        ),
        # Live feature availability table
        dmc.Paper(
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="tabler:key", width=20),
                            dmc.Text("Your features", fw=600),
                            dmc.Badge("reads clerk-auth-store.features", color="blue", variant="light", size="xs"),
                        ],
                        gap="sm",
                    ),
                    dmc.Table(
                        [
                            dmc.TableThead(
                                dmc.TableTr(
                                    [dmc.TableTh("Feature"), dmc.TableTh("What it unlocks"), dmc.TableTh("Access")]
                                )
                            ),
                            dmc.TableTbody([_feature_row(f) for f in FEATURES]),
                        ],
                        striped=True,
                        withTableBorder=True,
                    ),
                ],
                gap="sm",
            ),
            p="lg",
            radius="md",
            withBorder=True,
        ),
        # Demo
        dmc.Paper(
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="tabler:bolt", width=20),
                            dmc.Text("Try 'advanced_alerts'", fw=600),
                        ],
                        gap="sm",
                    ),
                    dmc.Button(
                        "Open advanced alerts",
                        id="require-feature-btn",
                        leftSection=DashIconify(icon="tabler:bell", width=16),
                    ),
                    html.Div(id="require-feature-output"),
                ],
                gap="sm",
            ),
            p="lg",
            radius="md",
            withBorder=True,
        ),
        # Code
        dmc.Title("Decorator usage", order=3, mt="md"),
        dmc.CodeHighlight(code=DECORATOR, language="python"),
        dmc.Title("Imperative check with has_feature()", order=3, mt="md"),
        dmc.CodeHighlight(code=HAS_FEATURE, language="python"),
    ],
    gap="md",
)


@callback(
    Output({"type": "feature-check", "name": dash.ALL}, "children"),
    Input("clerk-auth-store", "data"),
)
def _render_access(auth):
    features = (auth or {}).get("features") or []
    # Get the ordered list of feature names from the outputs
    ctx = dash.callback_context
    outs = ctx.outputs_list
    result = []
    for out in outs:
        name = out["id"]["name"]
        if name in features:
            result.append(
                dmc.Badge(
                    "granted",
                    color="green",
                    variant="light",
                    leftSection=DashIconify(icon="tabler:check", width=12),
                    size="sm",
                )
            )
        else:
            result.append(
                dmc.Badge(
                    "denied",
                    color="gray",
                    variant="light",
                    leftSection=DashIconify(icon="tabler:x", width=12),
                    size="sm",
                )
            )
    return result


@callback(
    Output("require-feature-output", "children"),
    Input("require-feature-btn", "n_clicks"),
    State("clerk-auth-store", "data"),
    prevent_initial_call=True,
)
def _try_feature(n, auth):
    if not auth or not auth.get("user_id"):
        return dmc.Alert(
            "Sign in to check your feature set.",
            color="yellow",
            icon=DashIconify(icon="tabler:alert-triangle"),
            mt="sm",
        )
    if "advanced_alerts" in (auth.get("features") or []):
        return dmc.Alert(
            "advanced_alerts is in your feature set — this panel would render the alert editor.",
            color="green",
            icon=DashIconify(icon="tabler:check"),
            mt="sm",
        )
    return dmc.Alert(
        dmc.Stack(
            [
                dmc.Text("Feature not available", fw=600),
                dmc.Text(
                    "@require_feature('advanced_alerts') blocked this callback. In a real "
                    "app you'd render an upgrade CTA or link to /billing here.",
                    size="sm",
                ),
            ],
            gap=4,
        ),
        color="orange",
        icon=DashIconify(icon="tabler:lock"),
        mt="sm",
    )