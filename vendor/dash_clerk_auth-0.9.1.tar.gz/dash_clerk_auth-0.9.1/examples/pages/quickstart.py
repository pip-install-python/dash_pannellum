"""
Quickstart — the minimum viable dash-clerk-auth integration.

Walks a new user from a blank virtualenv to a running app with sign-in UI in
four steps: install, env, register, run.
"""

import dash
import dash_mantine_components as dmc
from dash import html
from dash_iconify import DashIconify

dash.register_page(__name__, path="/quickstart", name="Quickstart", order=1)

STEP_1 = """# Flask backend (Dash 3.x or 4.x WSGI):
pip install 'dash-clerk-auth>=0.7.0' 'dash>=3.0.3' 'dash-mantine-components>=2.3.0'

# Dash 4 ASGI (FastAPI / Quart) — required for v0.7 WebSocket auth:
pip install 'dash-clerk-auth[fastapi]>=0.7.0' 'dash[fastapi]>=4.2.0rc1'"""

STEP_2_ENV = """# .env (same directory as app.py)
CLERK_SECRET_KEY=sk_test_xxxxxxxxxxxxxxxx
CLERK_PUBLISHABLE_KEY=pk_test_xxxxxxxxxxxxxxxx
CLERK_SIGN_IN_URL=https://your-app.clerk.accounts.dev/sign-in
# v0.7+: SESSION_SECRET signs both the session cookie AND the new __dca_identity
# verified-positive cache cookie. Use a random 32+ byte value.
SESSION_SECRET=generate-a-random-string-here
"""

STEP_3_APP = '''"""app.py"""
import os
from dotenv import load_dotenv
from dash import Dash
import dash_mantine_components as dmc
from dash_clerk_auth import register_clerk_auth, configure_app, create_clerk_menu

load_dotenv()

# 1. Register the hook BEFORE creating the Dash app — hooks fire on construction.
register_clerk_auth(
    clerk_secret_key=os.environ["CLERK_SECRET_KEY"],
    clerk_publishable_key=os.environ["CLERK_PUBLISHABLE_KEY"],
    clerk_sign_in_url=os.environ["CLERK_SIGN_IN_URL"],
    session_secret=os.environ["SESSION_SECRET"],   # v0.7 — signs __dca_identity
    backend="auto",           # v0.6 — autodetects flask vs fastapi from app.server
    debug=True,               # shows the debug panel in bottom-right
    enable_billing=False,     # flip to True for @require_plan / @require_feature
    headless=True,            # skip the fixed top-right avatar; embed ours below
)

app = Dash(__name__, external_stylesheets=[dmc.styles.ALL])
# For Dash 4 + FastAPI ASGI, use:
#   app = Dash(__name__, backend="fastapi", websocket_callbacks=True, ...)

# 2. Wire session cookies + /api/auth/* routes.
#    Flask: Flask-Session + before_request hook reading __dca_identity.
#    FastAPI: Starlette SessionMiddleware + ClerkASGIMiddleware (HTTP + WS).
configure_app(app)

# 3. (FastAPI/Quart on Dash 4.2 only — opt-in WebSocket auth):
# from dash_clerk_auth import register_websocket_auth
# register_websocket_auth(on_anonymous="allow")  # mixed-traffic safe (v0.7 default)

# 3. Layout — wrap in MantineProvider, drop create_clerk_menu() in the header.
app.layout = dmc.MantineProvider(
    dmc.AppShell(
        [
            dmc.AppShellHeader(
                dmc.Group(
                    [
                        dmc.Title("My app", order=4),
                        create_clerk_menu(),   # <-- avatar + dropdown lives here
                    ],
                    justify="space-between",
                    h="100%",
                    px="md",
                )
            ),
            dmc.AppShellMain(dmc.Container("Hello!", py="xl")),
        ],
        header={"height": 60},
        padding="md",
    )
)

if __name__ == "__main__":
    app.run(debug=True, port=8050)
'''

STEP_4 = "python app.py"


def _step(num, title, icon, body):
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.Badge(f"Step {num}", size="lg", variant="filled", color="blue"),
                    DashIconify(icon=icon, width=22),
                    dmc.Text(title, fw=600, size="lg"),
                ],
                gap="sm",
            ),
            dmc.Divider(my="sm"),
            body,
        ],
        p="lg",
        radius="md",
        withBorder=True,
    )


layout = dmc.Stack(
    [
        dmc.Title("Quickstart", order=1),
        dmc.Text(
            "Four steps from a fresh virtualenv to a Dash app with Clerk sign-in. "
            "Tested on Python 3.9 – 3.12, Dash 3.0.3 / 4.0 / 4.1 / 4.2.0rc3, "
            "Flask + FastAPI/Quart, dmc 2.3 – 2.6.",
            c="dimmed",
        ),
        _step(
            1,
            "Install the package",
            "tabler:package",
            dmc.Stack(
                [
                    dmc.Text("dash-clerk-auth pulls in Clerk's Python SDK, Flask-Session, and httpx automatically.", size="sm"),
                    dmc.CodeHighlight(code=STEP_1, language="bash"),
                ],
                gap="xs",
            ),
        ),
        _step(
            2,
            "Grab your Clerk keys",
            "tabler:key",
            dmc.Stack(
                [
                    dmc.List(
                        [
                            dmc.ListItem("Sign up at clerk.com and create an application."),
                            dmc.ListItem("Copy the Publishable Key and Secret Key from the dashboard."),
                            dmc.ListItem("Find the Frontend API URL — append /sign-in to build CLERK_SIGN_IN_URL."),
                            dmc.ListItem("Generate a random SESSION_SECRET (e.g. `python -c 'import secrets; print(secrets.token_hex(32))'`)."),
                        ],
                        size="sm",
                        spacing="xs",
                    ),
                    dmc.CodeHighlight(code=STEP_2_ENV, language="bash"),
                ],
                gap="xs",
            ),
        ),
        _step(
            3,
            "Write app.py",
            "tabler:code",
            dmc.Stack(
                [
                    dmc.Text(
                        "register_clerk_auth() must be called BEFORE Dash() — it registers "
                        "@hooks.index() and @hooks.layout() handlers that fire during app "
                        "construction. configure_app() autodetects the backend from "
                        "app.server: on Flask it wires Flask-Session + a before_request hook "
                        "that reads __dca_identity; on FastAPI/Quart it installs Starlette "
                        "SessionMiddleware + ClerkASGIMiddleware (which now handles HTTP "
                        "AND WebSocket scope so Dash 4.2 WS-served callbacks see the user). "
                        "Both backends mint the signed __dca_identity cookie on every "
                        "successful Clerk verify so subsequent requests skip the JWKS roundtrip.",
                        size="sm",
                    ),
                    dmc.CodeHighlight(code=STEP_3_APP, language="python"),
                ],
                gap="xs",
            ),
        ),
        _step(
            4,
            "Run it",
            "tabler:player-play",
            dmc.Stack(
                [
                    dmc.CodeHighlight(code=STEP_4, language="bash"),
                    dmc.Text(
                        "Visit http://localhost:8050. The avatar in the top-right opens the "
                        "Clerk sign-in modal. Once signed in, the clerk-auth-store dcc.Store "
                        "is populated and available to every callback in the app.",
                        size="sm",
                    ),
                ],
                gap="xs",
            ),
        ),
        dmc.Alert(
            dmc.Stack(
                [
                    dmc.Text("Already on 0.6.x? v0.7.0 is a drop-in upgrade.", fw=600),
                    dmc.List(
                        [
                            dmc.ListItem(
                                "Signed __dca_identity cookie caches the Clerk verdict — "
                                "every request after the first skips the JWKS roundtrip."
                            ),
                            dmc.ListItem(
                                "ClerkASGIMiddleware now handles WebSocket scope. Dash 4.2's "
                                "WS-served callbacks see the verified user immediately — no "
                                "more 'first paint shows anonymous, refresh fixes it' race."
                            ),
                            dmc.ListItem(
                                "register_websocket_auth(on_anonymous='allow') is the new "
                                "default — anonymous visitors keep their WS open instead of "
                                "getting closed with code 4401. Pass 'close' for v0.6 behaviour."
                            ),
                            dmc.ListItem(
                                "_ws.py rewritten against the real Dash 4.2.0rc3 hook names "
                                "(websocket_connect, websocket_message)."
                            ),
                            dmc.ListItem(
                                "@hooks.layout() pre-hydrates clerk-auth-store from the "
                                "cookie at build time — kills the first-paint anonymous flash."
                            ),
                        ],
                        size="sm",
                        spacing=4,
                    ),
                ],
                gap="xs",
            ),
            title="What changed in 0.7.0",
            color="blue",
            icon=DashIconify(icon="tabler:info-circle"),
        ),
    ],
    gap="md",
)