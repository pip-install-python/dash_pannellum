"""ClerkUser dataclass — JWT payload projection."""

from dash_clerk_auth import ClerkUser


def test_minimal_payload():
    u = ClerkUser.from_jwt_payload({"sub": "user_1"})
    assert u.user_id == "user_1"
    assert u.email is None
    assert u.role is None
    assert u.plan is None
    assert u.features == ()


def test_role_from_public_metadata_lowercased():
    u = ClerkUser.from_jwt_payload({"sub": "u", "public_metadata": {"role": "Admin"}})
    assert u.role == "admin"
    assert u.has_role("Admin")
    assert u.has_role("admin")
    assert not u.has_role("editor")


def test_role_from_org_role_strips_namespace():
    u = ClerkUser.from_jwt_payload({"sub": "u", "org_role": "org:admin"})
    assert u.role == "admin"


def test_role_top_level_fallback():
    u = ClerkUser.from_jwt_payload({"sub": "u", "role": "Editor"})
    assert u.role == "editor"


def test_billing_features_list():
    u = ClerkUser.from_jwt_payload(
        {"sub": "u", "plan": "pro", "features": ["seats:5", "exports"]},
        billing_enabled=True,
    )
    assert u.plan == "pro"
    assert u.features == ("seats:5", "exports")
    assert u.has_feature("exports")
    assert not u.has_feature("admin")


def test_billing_features_csv_string():
    u = ClerkUser.from_jwt_payload(
        {"sub": "u", "plan": "free", "features": "a, b ,c"},
        billing_enabled=True,
    )
    assert u.features == ("a", "b", "c")


def test_billing_disabled_skips_plan_extraction():
    u = ClerkUser.from_jwt_payload(
        {"sub": "u", "plan": "pro", "features": ["x"]},
        billing_enabled=False,
    )
    assert u.plan is None
    assert u.features == ()


def test_payload_without_sub_raises():
    import pytest

    with pytest.raises(ValueError):
        ClerkUser.from_jwt_payload({"email": "x"})


def test_to_session_dict_roundtrip():
    u = ClerkUser.from_jwt_payload(
        {"sub": "u", "email": "a@b.com", "first_name": "A", "plan": "pro"},
        billing_enabled=True,
    )
    sess = u.to_session_dict()
    u2 = ClerkUser.from_session_dict(sess)
    assert u2 is not None
    assert u2.user_id == "u"
    assert u2.email == "a@b.com"
    assert u2.plan == "pro"


def test_from_session_dict_no_user_id_returns_none():
    assert ClerkUser.from_session_dict({}) is None
    assert ClerkUser.from_session_dict({"email": "x"}) is None


def test_has_plan_accepts_str_or_iterable():
    u = ClerkUser(user_id="u", plan="pro")
    assert u.has_plan("pro")
    assert u.has_plan(["free", "pro"])
    assert not u.has_plan("enterprise")
    assert not ClerkUser(user_id="u").has_plan("pro")
