"""Backend-neutral current_user() dispatch."""

from __future__ import annotations

from dash_clerk_auth import ClerkUser, current_user, is_authenticated
from dash_clerk_auth._backend import (
    _CURRENT_USER,
    detect_backend,
    reset_request_user,
    set_request_user,
)


def test_outside_any_request_returns_none():
    assert current_user() is None
    assert is_authenticated() is False


def test_contextvar_path():
    user = ClerkUser(user_id="u_1", role="admin")
    token = set_request_user(user)
    try:
        assert current_user() is user
        assert is_authenticated() is True
    finally:
        reset_request_user(token)
    assert current_user() is None


def test_contextvar_isolation_between_resets():
    a = ClerkUser(user_id="a")
    b = ClerkUser(user_id="b")
    t1 = set_request_user(a)
    assert current_user().user_id == "a"
    t2 = set_request_user(b)
    assert current_user().user_id == "b"
    reset_request_user(t2)
    assert current_user().user_id == "a"
    reset_request_user(t1)
    assert current_user() is None


def test_detect_backend_unknown():
    assert detect_backend(None) == "unknown"


def test_detect_backend_starlette():
    from starlette.applications import Starlette

    assert detect_backend(Starlette()) == "fastapi"


def test_detect_backend_fastapi():
    from fastapi import FastAPI

    assert detect_backend(FastAPI()) == "fastapi"


def test_detect_backend_flask():
    from flask import Flask

    assert detect_backend(Flask(__name__)) == "flask"


def test_flask_g_path():
    """Inside a Flask request context, current_user() reads flask.g.clerk_user."""
    from flask import Flask, g

    app = Flask(__name__)
    user = ClerkUser(user_id="u_flask")

    with app.test_request_context("/"):
        g.clerk_user = user
        assert current_user() is user
    assert current_user() is None  # context cleared


def test_flask_session_fallback_when_g_empty():
    """If g.clerk_user wasn't populated, fall back to reconstructing from session."""
    from flask import Flask

    app = Flask(__name__)
    app.secret_key = "test"

    with app.test_request_context("/"):
        from flask import session

        session["user_id"] = "u_legacy"
        session["email"] = "x@y.com"
        u = current_user()
        assert u is not None
        assert u.user_id == "u_legacy"
        assert u.email == "x@y.com"


def test_contextvar_takes_priority_over_flask_g():
    """ContextVar wins over flask.g — set by ASGI middleware on requests
    that happen to also touch a Flask context (rare; defensive)."""
    from flask import Flask, g

    app = Flask(__name__)
    ctx_user = ClerkUser(user_id="ctx")
    g_user = ClerkUser(user_id="g")

    token = set_request_user(ctx_user)
    try:
        with app.test_request_context("/"):
            g.clerk_user = g_user
            assert current_user() is ctx_user
    finally:
        reset_request_user(token)
