"""Layout decorators — fail-closed by default, all three policies, both styles."""

from __future__ import annotations

from dash import html

from dash_clerk_auth import (
    ClerkUser,
    require_auth_layout,
    require_role_layout,
    require_plan_layout,
    require_feature_layout,
)
from dash_clerk_auth._backend import reset_request_user, set_request_user


PROTECTED = html.Div("admin", id="protected")
FORBIDDEN = html.Div("nope", id="forbidden")


def _build():
    return PROTECTED


def _set(user):
    return set_request_user(user)


# ---------------------------------------------------------------------------
# require_auth_layout
# ---------------------------------------------------------------------------
def test_auth_anonymous_default_forbidden():
    layout = require_auth_layout(forbidden=FORBIDDEN)(_build)
    assert layout() is FORBIDDEN


def test_auth_signed_in_returns_protected():
    layout = require_auth_layout(forbidden=FORBIDDEN)(_build)
    t = _set(ClerkUser(user_id="u"))
    try:
        assert layout() is PROTECTED
    finally:
        reset_request_user(t)


def test_auth_on_inconclusive_allow():
    layout = require_auth_layout(forbidden=FORBIDDEN, on_inconclusive="allow")(_build)
    assert layout() is PROTECTED  # anonymous → allowed through


def test_auth_on_inconclusive_passthrough_renders_both():
    layout = require_auth_layout(forbidden=FORBIDDEN, on_inconclusive="passthrough")(_build)
    out = layout()
    assert isinstance(out, html.Div)
    assert len(out.children) == 2  # placeholder + hidden protected


# ---------------------------------------------------------------------------
# require_role_layout
# ---------------------------------------------------------------------------
def test_role_admin_passes():
    layout = require_role_layout("admin", forbidden=FORBIDDEN)(_build)
    t = _set(ClerkUser(user_id="u", role="admin"))
    try:
        assert layout() is PROTECTED
    finally:
        reset_request_user(t)


def test_role_wrong_role_returns_forbidden_even_when_authenticated():
    """Authenticated-but-wrong-role is a deterministic 'no' — never goes through 'allow' policy."""
    layout = require_role_layout(
        "admin", forbidden=FORBIDDEN, on_inconclusive="allow"
    )(_build)
    t = _set(ClerkUser(user_id="u", role="editor"))
    try:
        assert layout() is FORBIDDEN
    finally:
        reset_request_user(t)


def test_role_anonymous_forbidden_by_default():
    layout = require_role_layout("admin", forbidden=FORBIDDEN)(_build)
    assert layout() is FORBIDDEN


def test_role_callable_layout_supported():
    """The decorator must support def layout(): return X form."""
    rendered = []

    def my_layout():
        rendered.append(True)
        return PROTECTED

    layout = require_role_layout("admin", forbidden=FORBIDDEN)(my_layout)
    t = _set(ClerkUser(user_id="u", role="admin"))
    try:
        assert layout() is PROTECTED
        assert rendered == [True]
    finally:
        reset_request_user(t)


def test_role_constant_layout_supported():
    """The decorator must also support layout = X form (non-callable)."""
    layout = require_role_layout("admin", forbidden=FORBIDDEN)(PROTECTED)
    t = _set(ClerkUser(user_id="u", role="admin"))
    try:
        assert layout() is PROTECTED
    finally:
        reset_request_user(t)


def test_role_default_forbidden_layout_used_when_none_passed():
    layout = require_role_layout("admin")(_build)
    out = layout()
    assert out is not None
    # Default placeholder is an html.Div with the lock emoji somewhere.
    assert isinstance(out, html.Div)


# ---------------------------------------------------------------------------
# require_plan_layout / require_feature_layout
# ---------------------------------------------------------------------------
def test_plan_match_single():
    layout = require_plan_layout("pro", forbidden=FORBIDDEN)(_build)
    t = _set(ClerkUser(user_id="u", plan="pro"))
    try:
        assert layout() is PROTECTED
    finally:
        reset_request_user(t)


def test_plan_match_multi():
    layout = require_plan_layout(["pro", "enterprise"], forbidden=FORBIDDEN)(_build)
    t = _set(ClerkUser(user_id="u", plan="enterprise"))
    try:
        assert layout() is PROTECTED
    finally:
        reset_request_user(t)


def test_plan_no_match():
    layout = require_plan_layout("pro", forbidden=FORBIDDEN)(_build)
    t = _set(ClerkUser(user_id="u", plan="free"))
    try:
        assert layout() is FORBIDDEN
    finally:
        reset_request_user(t)


def test_feature_match():
    layout = require_feature_layout("exports", forbidden=FORBIDDEN)(_build)
    t = _set(ClerkUser(user_id="u", features=("exports", "seats")))
    try:
        assert layout() is PROTECTED
    finally:
        reset_request_user(t)


def test_feature_missing():
    layout = require_feature_layout("exports", forbidden=FORBIDDEN)(_build)
    t = _set(ClerkUser(user_id="u", features=("seats",)))
    try:
        assert layout() is FORBIDDEN
    finally:
        reset_request_user(t)


def test_invalid_on_inconclusive_raises():
    import pytest

    with pytest.raises(ValueError):
        require_role_layout("admin", on_inconclusive="bogus")(_build)
