"""Loop-free synchronous Clerk helpers — safe inside Dash 4.2 WS callbacks.

These are the §8 "upstreamable" helpers: they never await an event-loop-bound
httpx client, so they can be called from the thread-pool worker that runs Dash
4.2 WebSocket callbacks (where the async client raises ``Event loop is closed``).
The Clerk client is mocked — no network I/O.
"""

from __future__ import annotations

import time
from types import SimpleNamespace

import pytest

from dash_clerk_auth import (
    verify_user_sync,
    get_user_by_id_sync,
    list_users_sync,
    set_user_role_sync,
)
from dash_clerk_auth._clerk_client import _is_closed_loop_error


# ---------------------------------------------------------------------------
# _is_closed_loop_error — must recognise every cross-loop RuntimeError phrasing
# so the async self-heal actually engages.
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    "msg",
    [
        "Event loop is closed",
        "<Future pending> attached to a different loop",
        "<asyncio.locks.Lock object at 0x1> is bound to a different event loop",
    ],
)
def test_is_closed_loop_error_matches_cross_loop_variants(msg):
    assert _is_closed_loop_error(RuntimeError(msg)) is True


@pytest.mark.parametrize(
    "exc",
    [
        RuntimeError("connection reset by peer"),
        ValueError("Event loop is closed"),  # right text, wrong type
    ],
)
def test_is_closed_loop_error_rejects_unrelated(exc):
    assert _is_closed_loop_error(exc) is False


class _Users:
    def __init__(self, state):
        self.state = state

    def get(self, *, user_id):
        self.state["get_calls"] += 1
        return self.state.get("user_obj", {"id": user_id})

    def list(self, *, request=None):
        self.state["list_calls"] += 1
        return self.state.get("users", [])

    def update_metadata(self, *, user_id, public_metadata):
        self.state["update_calls"] += 1
        self.state["last_update"] = (user_id, public_metadata)
        return {"id": user_id, "public_metadata": public_metadata}


class _MockSyncClient:
    def __init__(self, state):
        self.state = state
        self.users = _Users(state)

    def authenticate_request(self, request, options):
        self.state["auth_calls"] += 1
        return SimpleNamespace(
            is_signed_in=self.state["signed_in"],
            payload=self.state["payload"],
            reason="",
        )


@pytest.fixture
def sync_state(monkeypatch):
    state = {
        "signed_in": True,
        "payload": {"sub": "u_sync", "email": "s@x.com", "exp": time.time() + 600},
        "auth_calls": 0,
        "get_calls": 0,
        "list_calls": 0,
        "update_calls": 0,
        "users": [{"id": "u_1"}, {"id": "u_2"}],
    }
    from dash_clerk_auth import _clerk_client

    monkeypatch.setattr(_clerk_client, "get_sync_client", lambda: _MockSyncClient(state))
    return state


# ---------------------------------------------------------------------------
# verify_user_sync
# ---------------------------------------------------------------------------
def test_verify_user_sync_signed_in(sync_state):
    user = verify_user_sync(headers={"authorization": "Bearer t"})
    assert user is not None
    assert user.user_id == "u_sync"


def test_verify_user_sync_unsigned_returns_none(sync_state):
    sync_state["signed_in"] = False
    assert verify_user_sync(headers={"authorization": "Bearer t"}) is None


def test_verify_user_sync_caches(sync_state):
    headers = {"authorization": "Bearer same"}
    a = verify_user_sync(headers=headers)
    b = verify_user_sync(headers=headers)
    assert a is not None and b is not None
    assert sync_state["auth_calls"] == 1  # second call served from cache


# ---------------------------------------------------------------------------
# get_user_by_id_sync / list_users_sync
# ---------------------------------------------------------------------------
def test_get_user_by_id_sync_caches(sync_state):
    sync_state["user_obj"] = {"id": "u_42", "first_name": "X"}
    a = get_user_by_id_sync("u_42")
    b = get_user_by_id_sync("u_42")
    assert a["id"] == "u_42" and b == a
    assert sync_state["get_calls"] == 1
    # force re-fetches
    get_user_by_id_sync("u_42", force=True)
    assert sync_state["get_calls"] == 2


def test_list_users_sync_caches_and_force(sync_state):
    a = list_users_sync()
    b = list_users_sync()
    assert a == b == [{"id": "u_1"}, {"id": "u_2"}]
    assert sync_state["list_calls"] == 1
    list_users_sync(force=True)
    assert sync_state["list_calls"] == 2


# ---------------------------------------------------------------------------
# set_user_role_sync — merge-patch + cache invalidation
# ---------------------------------------------------------------------------
def test_set_user_role_sync_updates_and_invalidates(sync_state):
    # Prime the list cache so we can prove invalidation.
    list_users_sync()
    assert sync_state["list_calls"] == 1

    out = set_user_role_sync("u_42", "admin")
    assert out is not None
    assert sync_state["last_update"] == ("u_42", {"role": "admin"})
    assert out["public_metadata"] == {"role": "admin"}

    # The user-list cache was cleared, so the next list re-fetches.
    list_users_sync()
    assert sync_state["list_calls"] == 2
