"""v0.5 → v0.6 backwards-compat — kwargs, helpers, register_clerk_auth signature."""

from __future__ import annotations

import warnings


def test_v05_helpers_still_importable():
    from dash_clerk_auth import (
        register_clerk_auth,
        configure_app,
        create_clerk_menu,
        get_current_user_id,
        get_current_user_plan,
        get_current_user_features,
        has_plan,
        has_feature,
        require_auth,
        require_plan,
        require_feature,
        get_user_info,
    )

    # Just assert they're callable and don't crash outside a request context.
    assert callable(register_clerk_auth)
    assert callable(configure_app)
    assert get_current_user_id() is None
    assert get_user_info() is None
    # has_plan with billing disabled returns True (current_user is None,
    # billing_enabled defaults to False ⇒ short-circuits to True).
    assert has_plan("any") is True
    assert has_feature("any") is True


def test_flask_secret_key_still_accepted_with_deprecation_warning():
    """Calling register_clerk_auth(flask_secret_key=...) must keep working."""
    # Reset _clerk_config so re-registration succeeds in test isolation.
    import dash_clerk_auth as m

    m._clerk_config = {"initialized": False, "billing_enabled": False}

    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        m.register_clerk_auth(
            clerk_secret_key="sk_test_dummy",
            clerk_publishable_key="pk_test_dummy",
            clerk_sign_in_url="https://example.clerk.accounts.dev/sign-in",
            flask_secret_key="legacy-secret",
        )
    deps = [w for w in captured if issubclass(w.category, DeprecationWarning)]
    assert any("flask_secret_key" in str(w.message) for w in deps), (
        f"expected DeprecationWarning mentioning flask_secret_key; got {[str(w.message) for w in deps]}"
    )
    assert m._clerk_config["session_secret"] == "legacy-secret"
    # Internal alias still set so v0.5 code paths reading flask_secret_key work.
    assert m._clerk_config["flask_secret_key"] == "legacy-secret"

    # Reset for following tests.
    m._clerk_config = {"initialized": False, "billing_enabled": False}


def test_session_secret_takes_precedence_over_flask_secret_key():
    import dash_clerk_auth as m

    m._clerk_config = {"initialized": False, "billing_enabled": False}
    m.register_clerk_auth(
        clerk_secret_key="sk_test_dummy",
        clerk_publishable_key="pk_test_dummy",
        clerk_sign_in_url="https://example.clerk.accounts.dev/sign-in",
        session_secret="new-secret",
        flask_secret_key="old-secret",  # ignored when session_secret given
    )
    assert m._clerk_config["session_secret"] == "new-secret"
    m._clerk_config = {"initialized": False, "billing_enabled": False}


def test_v06_new_kwargs_accepted():
    import dash_clerk_auth as m

    m._clerk_config = {"initialized": False, "billing_enabled": False}
    m.register_clerk_auth(
        clerk_secret_key="sk_test_dummy",
        clerk_publishable_key="pk_test_dummy",
        clerk_sign_in_url="https://example.clerk.accounts.dev/sign-in",
        backend="fastapi",
        on_unverified="passthrough",
        verify_timeout=2.5,
        authorized_parties=["https://app.example.com"],
    )
    assert m._clerk_config["backend"] == "fastapi"
    assert m._clerk_config["on_unverified"] == "passthrough"
    assert m._clerk_config["verify_timeout"] == 2.5
    assert m._clerk_config["authorized_parties"] == ["https://app.example.com"]
    m._clerk_config = {"initialized": False, "billing_enabled": False}
