"""Signed identity cookie — round-trip, tampering, expiry, JWT-bounded TTL."""

from __future__ import annotations

import time

import pytest

from dash_clerk_auth import ClerkUser
from dash_clerk_auth._identity_cookie import (
    COOKIE_NAME,
    bounded_max_age,
    clear_cookie_header,
    flask_clear_cookie_kwargs,
    flask_set_cookie_kwargs,
    mint,
    set_cookie_header,
    verify,
)


SECRET = "test-secret-do-not-use-in-prod"


def _user(**overrides) -> ClerkUser:
    return ClerkUser.from_jwt_payload(
        {
            "sub": overrides.pop("user_id", "user_42"),
            "email": "a@b.com",
            "first_name": "Ada",
            "last_name": "Lovelace",
            **overrides,
        }
    )


def test_round_trip_returns_equivalent_user():
    user = _user()
    token = mint(user, SECRET)
    decoded = verify(token, SECRET, max_age=3600)
    assert decoded is not None
    assert decoded.user_id == user.user_id
    assert decoded.email == user.email
    assert decoded.first_name == "Ada"


def test_tampered_token_returns_none():
    token = mint(_user(), SECRET)
    # Flip a character in the middle to break the signature.
    bad = token[:-3] + ("AAA" if token[-3:] != "AAA" else "BBB")
    assert verify(bad, SECRET, max_age=3600) is None


def test_wrong_secret_returns_none():
    token = mint(_user(), SECRET)
    assert verify(token, "different-secret", max_age=3600) is None


def test_expired_token_returns_none():
    """A token signed >max_age seconds ago is rejected.

    itsdangerous timestamps with 1-second precision and triggers
    expiry on age STRICTLY GREATER than max_age, so we sleep >2s and
    verify with max_age=1 to leave no doubt the gate fires.
    """
    token = mint(_user(), SECRET)
    time.sleep(2.1)
    assert verify(token, SECRET, max_age=1) is None


def test_empty_inputs_return_none():
    assert verify("", SECRET, max_age=60) is None
    assert verify("anything", "", max_age=60) is None


def test_mint_requires_secret():
    with pytest.raises(ValueError):
        mint(_user(), "")


def test_set_cookie_header_includes_required_attrs():
    name, value = set_cookie_header("token-abc", max_age=300)
    assert name == b"set-cookie"
    s = value.decode("latin-1")
    assert s.startswith(f"{COOKIE_NAME}=token-abc")
    assert "Max-Age=300" in s
    assert "Path=/" in s
    assert "HttpOnly" in s
    assert "SameSite=Lax" in s
    assert "Secure" not in s


def test_set_cookie_header_secure_flag():
    _, value = set_cookie_header("t", max_age=10, secure=True)
    assert "Secure" in value.decode("latin-1")


def test_clear_cookie_header_uses_max_age_zero():
    _, value = clear_cookie_header()
    s = value.decode("latin-1")
    assert "Max-Age=0" in s
    assert s.startswith(f"{COOKIE_NAME}=")


def test_flask_kwargs_use_correct_keys():
    kw = flask_set_cookie_kwargs("v", max_age=60, secure=True)
    assert kw["key"] == COOKIE_NAME
    assert kw["value"] == "v"
    assert kw["max_age"] == 60
    assert kw["httponly"] is True
    assert kw["secure"] is True
    assert kw["samesite"] == "Lax"

    clear = flask_clear_cookie_kwargs()
    assert clear["max_age"] == 0
    assert clear["value"] == ""


def test_bounded_max_age_with_no_jwt_exp_returns_cap():
    assert bounded_max_age(None, 600) == 600


def test_bounded_max_age_clamps_to_jwt_exp():
    # JWT expires in 100s, cap is 3600 — bound to 100.
    soon = time.time() + 100
    result = bounded_max_age(soon, 3600)
    # Allow a few seconds of clock skew (the function reads time.time()
    # inside, so the result is < 100 but > 95).
    assert 95 <= result <= 100


def test_bounded_max_age_returns_zero_for_expired_jwt():
    past = time.time() - 60
    assert bounded_max_age(past, 3600) == 0


def test_bounded_max_age_enforces_minimum_cap_of_60s():
    # Even if cap=10 is requested, function clamps cap to >= 60s, then
    # min(cap, exp_remaining). With exp 1000s out, result = 60.
    far_future = time.time() + 1000
    assert bounded_max_age(far_future, 10) == 60


def test_role_round_trip():
    """Roles encoded into the session dict survive round-trip."""
    user = ClerkUser.from_jwt_payload({"sub": "u1", "role": "admin"})
    token = mint(user, SECRET)
    decoded = verify(token, SECRET, max_age=3600)
    assert decoded is not None
    assert decoded.role == "admin"
    assert decoded.has_role("admin")
